import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
import matplotlib.pyplot as plt
from matplotlib.tri import Triangulation

# 参数设置
E = 210e9  # 弹性模量 (Pa)
nu = 0.3    # 泊松比
t = 0.01    # 厚度 (m)
L = 2.0     # 梁长 (m)
H = 0.5     # 梁高 (m)
nx = 50     # x方向单元数
ny = 10     # y方向单元数
total_force = 1000.0  # 总载荷 (N)

# 生成节点
nx_nodes = nx + 1
ny_nodes = ny + 1
nodes = []
for j in range(ny_nodes):
    for i in range(nx_nodes):
        x = i * L / nx
        y = j * H / ny
        nodes.append((x, y))
nodes = np.array(nodes)
num_nodes = len(nodes)

# 生成三角形单元
elements = []
for j in range(ny):
    for i in range(nx):
        n0 = i + j * nx_nodes
        n1 = n0 + 1
        n2 = n0 + nx_nodes
        n3 = n2 + 1
        elements.append([n0, n1, n3])
        elements.append([n0, n3, n2])
elements = np.array(elements)
num_elements = len(elements)

def compute_stiffness_matrix(node1, node2, node3, E, nu, t):
    x1, y1 = node1
    x2, y2 = node2
    x3, y3 = node3
    A = 0.5 * abs((x2 - x1)*(y3 - y1) - (y2 - y1)*(x3 - x1))
    b1, b2, b3 = y2 - y3, y3 - y1, y1 - y2
    c1, c2, c3 = x3 - x2, x1 - x3, x2 - x1
    B = np.array([
        [b1, 0, b2, 0, b3, 0],
        [0, c1, 0, c2, 0, c3],
        [c1, b1, c2, b2, c3, b3]
    ]) / (2 * A)
    D = E / (1 - nu**2) * np.array([
        [1, nu, 0],
        [nu, 1, 0],
        [0, 0, (1 - nu)/2]
    ])
    Ke = (B.T @ D @ B) * (A * t)
    return Ke

# 组装全局刚度矩阵
num_dofs = 2 * num_nodes
K = sp.lil_matrix((num_dofs, num_dofs), dtype=np.float64)
for elem in elements:
    n1, n2, n3 = elem
    Ke = compute_stiffness_matrix(nodes[n1], nodes[n2], nodes[n3], E, nu, t)
    dofs = [2*n1, 2*n1+1, 2*n2, 2*n2+1, 2*n3, 2*n3+1]
    for i in range(6):
        for j in range(6):
            K[dofs[i], dofs[j]] += Ke[i, j]
K = K.tocsr()

# 处理边界条件
left_nodes = [i for i in range(num_nodes) if nodes[i, 0] == 0]
boundary_dofs = [d for n in left_nodes for d in [2*n, 2*n+1]]
for dof in boundary_dofs:
    K[dof, :] = 0
    K[dof, dof] = 1

# 施加载荷
F = np.zeros(num_dofs)
right_nodes = [i for i in range(num_nodes) if nodes[i, 0] == L]
force_per_node = total_force / len(right_nodes)
for n in right_nodes:
    F[2*n] = force_per_node
for dof in boundary_dofs:
    F[dof] = 0

# 求解位移
u = spla.spsolve(K, F)

# 计算应力
stresses = []
for elem in elements:
    n1, n2, n3 = elem
    u_e = np.array([u[2*n1], u[2*n1+1], u[2*n2], u[2*n2+1], u[2*n3], u[2*n3+1]])
    node1, node2, node3 = nodes[n1], nodes[n2], nodes[n3]
    x1, y1 = node1
    x2, y2 = node2
    x3, y3 = node3
    A = 0.5 * abs((x2 - x1)*(y3 - y1) - (y2 - y1)*(x3 - x1))
    b1, b2, b3 = y2 - y3, y3 - y1, y1 - y2
    c1, c2, c3 = x3 - x2, x1 - x3, x2 - x1
    B = np.array([
        [b1, 0, b2, 0, b3, 0],
        [0, c1, 0, c2, 0, c3],
        [c1, b1, c2, b2, c3, b3]
    ]) / (2 * A)
    D = E / (1 - nu**2) * np.array([[1, nu, 0], [nu, 1, 0], [0, 0, (1 - nu)/2]])
    stress = D @ (B @ u_e)
    stresses.append(stress)
stresses = np.array(stresses)

# 可视化
tri = Triangulation(nodes[:,0], nodes[:,1], elements)

plt.figure(figsize=(10, 4))
plt.tricontourf(tri, u[::2], levels=20, cmap='viridis')
plt.colorbar(label='Displacement u (m)')
plt.title('X-Direction Displacement')
plt.xlabel('X')
plt.ylabel('Y')
plt.show()

plt.figure(figsize=(10, 4))
plt.tripcolor(tri, stresses[:,0], shading='flat', cmap='jet')
plt.colorbar(label='Stress σ_x (Pa)')
plt.title('X-Direction Stress')
plt.xlabel('X')
plt.ylabel('Y')
plt.show()

plt.figure(figsize=(10, 4))
plt.tripcolor(tri, stresses[:,1], shading='flat', cmap='jet')
plt.colorbar(label='Stress σ_y (Pa)')
plt.title('Y-Direction Stress')
plt.xlabel('X')
plt.ylabel('Y')
plt.show()