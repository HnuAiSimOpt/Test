clear
clc
%% ��ʼ����
load data_L;                %load data 
emodule=2E+11;              %elastic modulus(MPa)
poisson=0.3;                %possion
nnel=8;                     %number of nodes per element
ndof=3;                     %number of dofs per node
nel=size(nodes,1);          %number of element
nnode=size(x0,1);           %total number of nodes in system    
sdof=nnode*ndof;            %total system dofs
edof=nnel*ndof;             %degrees of freedom per element
nglx=2;ngly=2;nglz=2;       %2x2 Gauss-Legendre quadrature
nglxyz=nglx*ngly*nglz;      %number of sampling points per element
fload=4;                    %the total load
%% ��ʼ������
ff=sparse(sdof,1);			%system force vector
k=sparse(edof,edof);		%initialization of element matrix
kk=zeros(sdof,sdof);		%system matrix
disp=sparse(sdof,1);		%system displacement vector
total_disp=zeros(nnode,1);  %total displacement vector
eldisp=sparse(edof,1);		%element displacement vector
stress=zeros(nel,8,7);		%matrix containing stress components
strain=zeros(nel,8,6);		% matrix containing strain components (modified from sparse)
index=sparse(edof,1);		%index vector
kinmtx3=sparse(6,edof);		%kinematic matrix
matmtx=sparse(6,6);			%constitutive matrix
%% �նȾ������
[point2,weight2]=feglqd2(nglx,ngly,nglz);    %sampling points & weights
matmtx=fematiso(4,emodule,poisson);     %constitutive matrice
for iel=1:nel       %loop for the total number of element
    for i=1:nnel
        nd(i)=nodes(iel,i);         %extract nodes for (iel)-th element
        xcoord(i)=x0(nd(i),1);      %extract x value of the node
        ycoord(i)=x0(nd(i),2);      %extract y value of the node
        zcoord(i)=x0(nd(i),3);      %extract y value of the node
    end
    k=sparse(edof,edof);            %numerical integration
    for intx=1:nglx
        x=point2(intx,1);           %sampling point in x-axis
        wtx=weight2(intx,1);        %weight in x-axis
        for inty=1:ngly
            y=point2(inty,2);       %sampling point in y-axis
            wty=weight2(inty,2);    %weight in y-axis
            for intz=1:nglz
                z=point2(intz,3);       %sampling point in z-axis
                wtz=weight2(intz,3);    %weight in z-axis
                [shape,dhdr,dhds,dhdt]=feisoq8(x,y,z);     %compute shape functions and derivatives at sampling point
                jacob3=fejacob3(nnel,dhdr,dhds,dhdt,xcoord,ycoord,zcoord);  %compute Jacobian
                detjacob=det(jacob3);                           %determinant of Jacobian
                invjacob=inv(jacob3);                           %inverse of Jacobian matrix
                [dhdx,dhdy,dhdz]=federiv3(nnel,dhdr,dhds,dhdt,invjacob);  %derivatives w.r.t physical coordinate
                kinmtx3=fekine3d(nnel,dhdx,dhdy,dhdz);               %kinematic matrice
                k=k+kinmtx3'*matmtx*kinmtx3*wtx*wty*wtz*detjacob;   %element stiffness matrice
            end
        end
    end
    index=feeldof(nd,nnel,ndof);        %extract system dofs for the element 
    kk=feasmb_2(kk,k,index);            %assemble element matrics
end
kk1=kk;
ff(bcfload,1)=fload;  %force vector  
[kk,ff]=feaplyc2(kk,ff,bcdof,bcval); %apply boundary condition
%solve the matrix equation
[LL,UU]=lu(kk);
utemp=LL\ff;
disp=UU\utemp;
disp_x=zeros(nnode,1);
disp_y=zeros(nnode,1);
disp_z=zeros(nnode,1);
for i=1:nnode
    total_disp(i)=sqrt(disp(3*(i-1)+1,1)^2+disp(3*(i-1)+2,1)^2+disp(3*(i-1)+3,1)^2);
    disp_x(i)=disp(3*(i-1)+1,1);
    disp_y(i)=disp(3*(i-1)+2,1);
    disp_z(i)=disp(3*(i-1)+3,1);
end
disp_value=[max(disp_x) min(disp_x);max(disp_y) min(disp_y);max(disp_z) min(disp_z);max(total_disp) min(total_disp)];
%% Ӧ��Ӧ�����
a=(1/sqrt(3))*[-1 -1 -1;1 -1 -1;1 1 -1;-1 1 -1;-1 -1 1;1 -1 1;1 1 1;-1 1 1];
stab=zeros(8,8); %stress transfer matrix
for i=1:nnel 
    stab(i,1)=(1/8)*(1-a(i,1))*(1-a(i,2))*(1-a(i,3));
    stab(i,2)=(1/8)*(1+a(i,1))*(1-a(i,2))*(1-a(i,3));
    stab(i,3)=(1/8)*(1+a(i,1))*(1+a(i,2))*(1-a(i,3));
    stab(i,4)=(1/8)*(1-a(i,1))*(1+a(i,2))*(1-a(i,3));
    stab(i,5)=(1/8)*(1-a(i,1))*(1-a(i,2))*(1+a(i,3));
    stab(i,6)=(1/8)*(1+a(i,1))*(1-a(i,2))*(1+a(i,3));
    stab(i,7)=(1/8)*(1+a(i,1))*(1+a(i,2))*(1+a(i,3));
    stab(i,8)=(1/8)*(1-a(i,1))*(1+a(i,2))*(1+a(i,3));
end
stab=inv(stab);
estress_x=zeros(nel,nnel);
estress_y=zeros(nel,nnel);
estress_z=zeros(nel,nnel);
estress_xy=zeros(nel,nnel);
estress_xz=zeros(nel,nnel);
estress_yz=zeros(nel,nnel);
estress_mises=zeros(nel,nnel);
for iel=1:nel       %loop for the total number of element
    for i=1:nnel
        nd(i)=nodes(iel,i);         %extract nodes for (iel)-th element
        xcoord(i)=x0(nd(i),1);      %extract x value of the node
        ycoord(i)=x0(nd(i),2);      %extract y value of the node
        zcoord(i)=x0(nd(i),3);      %extract z value of the node
    end
    k=sparse(edof,edof);
    pk=0;
    gstress=zeros(6,8);
    gstrain=zeros(6,8);  % initialize gauss point strains
    for intz=1:nglz
        z=point2(intz,3);           %sampling point in z-axis
        wtz=weight2(intz,3);        %weight in z-axis
        for inty=1:ngly
            y=point2(inty,2);       %sampling point in y-axis
            wty=weight2(inty,2);    %weight in y-axis
            for intx=1:nglx
                x=point2(intx,1);       %sampling point in x-axis
                wtx=weight2(intx,1);    %weight in x-axis
                [shape,dhdr,dhds,dhdt]=feisoq8(x,y,z);     %compute shape functions and derivatives at sampling point
                jacob3=fejacob3(nnel,dhdr,dhds,dhdt,xcoord,ycoord,zcoord);  %compute Jacobian
                detjacob=det(jacob3);                           %determinant of Jacobian
                invjacob=inv(jacob3);                           %inverse of Jacobian matrix
                [dhdx,dhdy,dhdz]=federiv3(nnel,dhdr,dhds,dhdt,invjacob);  %derivatives w.r.t physical coordinate
                kinmtx3=fekine3d(nnel,dhdx,dhdy,dhdz);               %kinematic matrice
                index=feeldof(nd,nnel,ndof);  %extract system dofs for the element
                for i=1:edof
                    eldisp(i,1)=disp(index(i));
                end
                estrain=kinmtx3*eldisp;             % compute strains
                estress=matmtx*estrain;             % compute stresses
                pk=pk+1;
                gstress(:,pk)=estress;
                gstrain(:,pk)=estrain;  % store gauss point strains
            end
        end
    end
    for i=1:6
        for j=1:8
            for n=1:8
                stress(iel,j,i)= stress(iel,j,i)+stab(j,n)*gstress(i,n);
            end
        end
    end
    for i=1:6
        for j=1:8
            for n=1:8
                strain(iel,j,i)= strain(iel,j,i)+stab(j,n)*gstrain(i,n);
            end
        end
    end
    %calculate Von-mises
     for i=1:nnel
        estress_x(iel,i)=stress(iel,i,1);
        estress_y(iel,i)=stress(iel,i,2);
        estress_z(iel,i)=stress(iel,i,3);
        estress_xy(iel,i)=stress(iel,i,6);
        estress_xz(iel,i)=stress(iel,i,5);
        estress_yz(iel,i)=stress(iel,i,4);
        estress_mises(iel,i)=fevon_mises(estress_x(iel,i),estress_y(iel,i),estress_z(iel,i),...
        estress_xy(iel,i),estress_xz(iel,i),estress_yz(iel,i));
    end
    for i=1:nnel
        stress(iel,i,7)=estress_mises(iel,i);
    end
end
neigh_node=cell(nnode,1);
neigh_node_ind=cell(nnode,1);
indneigh=zeros(1,nnode);
for i=1:nel
    for j=1:8
        indneigh(nodes(i,j))=indneigh(nodes(i,j))+1;
        neigh_node{nodes(i,j)}(indneigh(nodes(i,j)))=i;  %The element in which the node appears
        neigh_node_ind{nodes(i,j)}(indneigh(nodes(i,j)))=j;  %Node number in the element
    end
end
stress_node=zeros(7,nnode);

%��ʼ���ڵ�Ӧ�����
strain_node=zeros(6,nnode);  
for inode=1:nnode
    numel=indneigh(inode);
    for i=1:numel
        ind_nel=neigh_node{inode}(i);
        ind_nod=neigh_node_ind{inode}(i);
        % Ӧ��ƽ��
        for j=1:7
            stress_node(j,inode)=stress_node(j,inode)+stress(ind_nel,ind_nod,j);
        end
        % Ӧ��ƽ��
        for j=1:6
            strain_node(j,inode)=strain_node(j,inode)+strain(ind_nel,ind_nod,j);
        end
    end
    stress_node(:,inode)=stress_node(:,inode)/numel; %Smooth stress
    strain_node(:,inode)=strain_node(:,inode)/numel; % ADDED: Smooth strain
end
stress_value=[max(stress_node(7,:)) min(stress_node(7,:))]; %The extremum of the Von-mises
% ��Ч��Ӧ�乫ʽ
equivalent_strain = sqrt( (2/3) * (...
    strain_node(1,:).^2 + ...
    strain_node(2,:).^2 + ...
    strain_node(3,:).^2 + ...
    2*(strain_node(4,:).^2 + ...
       strain_node(5,:).^2 + ...
       strain_node(6,:).^2) ...
    )) / (1 + poisson); 

%% ������
fid_out=fopen('djc.plt','w');
fprintf(fid_out,'TITLE="test case governed by poisson equation"\n');

% 
fprintf(fid_out,'VARIABLES="x" "y" "z" "disp_x" "disp_y" "disp_z" "total_disp" "Von-Mises"');
fprintf(fid_out,' "Strain_xx" "Strain_yy" "Strain_zz" "Strain_xy" "Strain_xz" "Strain_yz" "Equivalent_Strain"\n'); 

fprintf(fid_out,'ZONE T="flow-field",N=%8d,E=%8d,ET=BRICK,F=FEPOINT\n',nnode,nel);

%  ����ڵ����ݣ���Ӧ��͵�Ч��Ӧ�䣩
for i=1:nnode
    % ǰ8�У����ꡢλ�ơ���λ�ơ�Von-MisesӦ��
    fprintf(fid_out,'%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e',...
        x0(i,1),x0(i,2),x0(i,3),...
        disp(3*(i-1)+1,1),disp(3*(i-1)+2,1),disp(3*(i-1)+3,1),...
        total_disp(i,1),stress_node(7,i));
    
    % ��7�� - 6��Ӧ����� + ��Ч��Ӧ��
    fprintf(fid_out,'%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e%16.6e\n',...
        strain_node(1,i),...   % Strain_xx
        strain_node(2,i),...   % Strain_yy
        strain_node(3,i),...   % Strain_zz
        strain_node(4,i),...   % Strain_xy
        strain_node(5,i),...   % Strain_xz
        strain_node(6,i),...   % Strain_yz
        equivalent_strain(i)); % Equivalent_Strain
end

% �����Ԫ������Ϣ
for i=1:nel
    fprintf(fid_out,'%8d%8d%8d%8d%8d%8d%8d%8d\n',...
        nodes(i,1),nodes(i,2),nodes(i,3),nodes(i,4),...
        nodes(i,5),nodes(i,6),nodes(i,7),nodes(i,8));
end
fclose(fid_out);
