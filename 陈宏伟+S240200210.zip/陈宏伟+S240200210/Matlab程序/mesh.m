function [geom,connec] = mesh()

model = createpde();


C1 = [1,...      
      50, 25, ...
      10]';      

% �����������
R1 = [3,...             
      4,...             
      0 ,100,100,0 ,... 
      0 ,  0, 50,50]';  


maxLength = max(length(C1), length(R1));
C1(end+1:maxLength) = nan;
R1(end+1:maxLength) = nan;

gd = [R1, C1]; 
sf = 'R1-C1';  
ns = char('R1', 'C1');
                      
ns = ns';             
                      
g = decsg(gd, sf, ns);     
geometryFromEdges(model,g);

mesh = generateMesh(model,...
                    'Hmax', 2, ... 
                    'Hmin', 1,...   
                    'Hgrad', 1.2,...
                    'Geometricorder','linear');   
                                                  
nodes = mesh.Nodes;        
elements = mesh.Elements;  
elements =elements';       

geom=nodes';               
connec= elements;          

figure('Name','���ڵ������ε�Ԫ����Ԫ����ģ��');
title('���ڵ������ε�Ԫ����Ԫ����ģ��');
patch('Faces', connec, 'Vertices', geom, 'FaceColor', 'c', 'Marker', 'o',...
      'MarkerFaceColor', 'g', 'MarkerSize', 3); 
axis on;
axis equal;

end
