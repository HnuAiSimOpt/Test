 function[dee] = formdee(E,vu)
 
 c=E/(1.-vu*vu);
 dee=c*[1   vu  0  ;
       vu    1  0  ;
       0     0  5*(1.-vu)];
