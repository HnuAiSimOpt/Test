clc
clear all

global  nnd nel nne nodof eldof  n
global  geom connec nf Nodal_loads dee 

format long g

E = 2.1e5;         
vu = 0.30;         
thick = 2;         

[geom,connec] = mesh();
                         
nnd = size(geom, 1);     
nel = size(connec, 1);   

nne = 3;           
nodof = 2;         
eldof = nne*nodof; 

scaleFactor = 100; 


nf = ones(nnd, nodof);             
for i=1:nnd 
    if geom(i,1) == 0
        nf(i,:) = [0, 0];          
    end                                     
end

Nodal_loads= zeros(nnd, 2);               
Force = -1000; 
for i=1:nnd
    if geom(i,1) == 100 && geom(i,2) == 50.
        Nodal_loads(i,:) = [0, Force ]; 
    end                                 
end


n=0;                                        
for i=1:nnd
    for j=1:nodof
        if nf(i,j) ~= 0
            n=n+1;
            nf(i,j)=n;
        end
    end
end

fg=zeros(n,1);                               
for i=1: nnd
    if nf(i,1) ~= 0
        fg(nf(i,1))= Nodal_loads(i,1);
    end
    if nf(i,2) ~= 0
        fg(nf(i,2))= Nodal_loads(i,2);
    end
end


dee = formdee(E,vu);        
kk = zeros(n, n);           
for i=1:nel
    [bee,g,A] = elem_T3(i) ;
    ke=thick*A*bee'*dee*bee;              
    kk=form_kk(kk,ke, g);                 
end


delta = kk\fg ;      
                                          
for i=1: nnd
    if nf(i,1) == 0
        x_disp =0.;
    else
        x_disp = delta(nf(i,1));
    end
    if nf(i,2) == 0
        y_disp = 0.;
    else
        y_disp = delta(nf(i,2));
    end
    node_disp(i,:) = [x_disp y_disp];
                                     
end

for i=1:nel
    [bee,g,A] = elem_T3(i) ;                 
    eld=zeros(eldof,1);     
    for m=1:eldof
        if g(m)==0
            eld(m)=0;
        else
            eld(m)=delta(g(m)); 
        end
    end
    eps=bee*eld;                       
    sigma=dee*eps;                     
    EPS(i,:)=eps;                      
    SIGMA(i,:)=sigma ;                
end



[EX,EY,ET,ZX,ZY,ZT,Z1,Z2]=contour_data(EPS,SIGMA); 

myColor=1/255*[0,0,255;  0,93,255;   0,185,255;  0,255,232;
    0,255,139;  0,255,46;  46,255,0;  139,255,0;
    232,255,0;  255,185,0; 255,93,0;  255,0,0];

deformedXY = geom;  
for i = 1:nnd
    deformedXY(i, 1) = geom(i, 1) + scaleFactor * node_disp(i, 1);  
    
    deformedXY(i, 2) = geom(i, 2) + scaleFactor * node_disp(i, 2);  
end
figure('Name','����ͼ');
title('����ͼ');
patch('Faces', connec, 'Vertices', deformedXY, 'FaceColor', 'c', 'Marker', 'o',...
      'MarkerFaceColor', 'g', 'MarkerSize', 3); 
axis on;
axis equal;

%Ux λ����ͼ
figure('Name','Ux λ����ͼ');
title('Ux λ����ͼ');
for i = 1:nel
    nodes = connec(i, :);
    x_patch = geom(nodes, 1);
    y_patch = geom(nodes, 2);
    Ux = node_disp(:, 1); 
    c_patch = Ux(nodes);
    patch(x_patch, y_patch, c_patch, 'EdgeColor', 'none');
end
colormap(myColor);
caxis([min(Ux), max(Ux)]);                            
t1=caxis;
t1=linspace(t1(1),t1(2),13);
colorbar('ytick',t1,'Location','westoutside');
axis equal;
axis on;

%Uy λ����ͼ
figure('Name','Uy λ����ͼ');
title('Uy λ����ͼ');
for i = 1:nel
    nodes = connec(i, :);
    x_patch = geom(nodes, 1);
    y_patch = geom(nodes, 2);
    Uy = node_disp(:, 2); 
    c_patch = Uy(nodes);
    patch(x_patch, y_patch, c_patch, 'EdgeColor', 'none');
end
colormap(myColor);
caxis([min(Uy), max(Uy)]);                            
t1=caxis;
t1=linspace(t1(1),t1(2),13);
colorbar('ytick',t1,'Location','westoutside');
axis equal;
axis on;

%��x Ӧ����ͼ
figure('Name','��x Ӧ����ͼ');
title('\sigma_xӦ����ͼ');
for i = 1:nel
    nodes = connec(i, :);
    x_patch = geom(nodes, 1);
    y_patch = geom(nodes, 2);
    c_patch = ZY(nodes);
    patch(x_patch, y_patch, c_patch, 'EdgeColor', 'none');
end
colormap(myColor);
caxis([min(ZY), max(ZY)]);                            
t1=caxis;
t1=linspace(t1(1),t1(2),13);
colorbar('ytick',t1,'Location','westoutside');
axis on;
axis equal;

%��y Ӧ����ͼ
figure('Name','��y Ӧ����ͼ');
title('\sigma_yӦ����ͼ');
for i = 1:nel
    nodes = connec(i, :);
    x_patch = geom(nodes, 1);
    y_patch = geom(nodes, 2);
    c_patch = ZX(nodes);
    patch(x_patch, y_patch, c_patch, 'EdgeColor', 'none');
end
colormap(myColor);
caxis([min(ZX), max(ZX)]);                            
t1=caxis;
t1=linspace(t1(1),t1(2),13);
colorbar('ytick',t1,'Location','westoutside');
axis equal;
axis on;

% ��Ӧ����ͼ
figure('Name','��Ӧ����ͼ');
title('��Ӧ����ͼ');
for i = 1:nel
    nodes = connec(i, :);
    x_patch = geom(nodes, 1);
    y_patch = geom(nodes, 2);
    c_patch = ZT(nodes);
    patch(x_patch, y_patch, c_patch, 'EdgeColor', 'none');
end
colormap(myColor);
caxis([min(ZT), max(ZT)]);                            
t1=caxis;
t1=linspace(t1(1),t1(2),13);
colorbar('ytick',t1,'Location','westoutside');
axis on;
axis equal;

%��x Ӧ����ͼ
figure('Name','��x Ӧ����ͼ');
title('��_{x}Ӧ����ͼ');
for i = 1:nel
    nodes = connec(i, :);
    x_patch = geom(nodes, 1);
    y_patch = geom(nodes, 2);
    c_patch = EY(nodes);
    patch(x_patch, y_patch, c_patch, 'EdgeColor', 'none');
end
colormap(myColor);
caxis([min(EY), max(EY)]);                           
t1=caxis;
t1=linspace(t1(1),t1(2),13);
colorbar('ytick',t1,'Location','westoutside');
axis equal;
axis on;

%��y Ӧ����ͼ
figure('Name','��y Ӧ����ͼ');
title('��_{y}Ӧ����ͼ');
for i = 1:nel
    nodes = connec(i, :);
    x_patch = geom(nodes, 1);
    y_patch = geom(nodes, 2);
    c_patch = EX(nodes);
    patch(x_patch, y_patch, c_patch, 'EdgeColor', 'none');
end
colormap(myColor);
caxis([min(EX), max(EX)]);                            
t1=caxis;
t1=linspace(t1(1),t1(2),13);
colorbar('ytick',t1,'Location','westoutside');
axis equal;
axis on;
