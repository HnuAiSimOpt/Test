function [EX,EY,ET,ZX,ZY,ZT,Z1,Z2] = contour_data(EPS,SIGMA)

    global nnd nel nne geom connec

    % ��ʼ���������
    EX = zeros(nnd, 1); 
    EY = zeros(nnd, 1); 
    ET = zeros(nnd, 1); 
    ZX = zeros(nnd, 1); 
    ZY = zeros(nnd, 1);  
    ZT = zeros(nnd, 1); 
    Z1 = zeros(nnd, 1); 
    Z2 = zeros(nnd, 1);  

  
    for k = 1:nnd
        ex = 0; ey = 0; et = 0;
        sigx = 0; sigy = 0; tau = 0;
        ne = 0;

        for iel = 1:nel
            for jel = 1:nne
                if connec(iel, jel) == k
                    ne = ne + 1;
                    ex = ex + EPS(iel, 1);        
                    ey = ey + EPS(iel, 2);        
                    et = et + EPS(iel, 3);        
                    sigx = sigx + SIGMA(iel, 1);  
                    sigy = sigy + SIGMA(iel, 2);  
                    tau = tau + SIGMA(iel, 3);    
                end
            end
        end
 

        if ne > 0
            EX(k) = ex / ne;   
            EY(k) = ey / ne;    
            ET(k) = et / ne;    
            ZX(k) = sigx / ne; 
            ZY(k) = sigy / ne;  
            ZT(k) = tau / ne;  

            Z1(k) = (ZX(k) + ZY(k)) / 2 + sqrt( ((ZX(k) - ZY(k)) / 2)^2 + ZT(k)^2 );
            Z2(k) = (ZX(k) + ZY(k)) / 2 - sqrt( ((ZX(k) - ZY(k)) / 2)^2 + ZT(k)^2 );
        end
    end
end