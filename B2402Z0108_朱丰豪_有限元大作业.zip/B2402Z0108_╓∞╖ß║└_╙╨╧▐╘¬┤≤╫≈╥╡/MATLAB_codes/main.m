clear;clc;close all
%% 绘图
figure
rectangle('Position',[0,0,300,20],'Linewidth',2,'LineStyle','-','EdgeColor','b')
axis([0 320 0 50])
% axis equal
xlabel('x轴');ylabel('y轴'); title('图形'); 
% 边上节点（设置上下边种子节点）
nx = 0:2:300;
ny = 0:2:20;
%% 画网格
%以2x2mm四边形单元划分网格，单元数为10x150，节点数为11x151
hold on
n = 150;
m = 10;% 横向网格数目
for i=1:n
    %画竖线
    plot([nx(i),nx(i)],[0,20],'k');
    x1(i,:) = nx(i)*ones(m+1,1);%从上至下
    y1(i,:) = linspace(20,0,m+1);%从左至右
end
%绘制横线
x1 = [x1;300*ones(1,11)];
y1 = [y1;y1(end,:)];
for i=1:m-1
     plot([0,300],[ny(i+1),ny(i+1)],'k');
end
x1 = x1';
y1 = y1';
% 单元、编号
m = 10;
for j=1:150   %列号，150列单元，151列点
    for i=1:10  %行号，10行单元，11行点
        % 从上至下，从左至右编号
        p1=i+(j-1)*(m+1);%第j列，第i行编号（四边形第一个点）
        p2=i+1+(j-1)*(m+1); %第j列，第i+1行编号
        p3=i+1+j*(m+1); %第j+1列，第i+1行编号
        p4=i+j*(m+1);%第j+1列，第i行编号 
        t=i+(j-1)*m; %单元的编号，从上至下，从左至右
        % 单元包括的点的编号
        e(t,:)=[p1,p2,p3,p4];
    end
end
%% 计算总刚度矩阵
E = 70E9;%弹性模量
NU = 0.33;%泊松比
h = 1;%厚度
K = zeros(2*11*151,2*11*151);
k = zeros(8,8);
%组装总体刚度矩阵
for j=1:10%i是单元的行号，j是单元的列号
    for i=1:150
        t=i+(j-1)*150;
        p1=e(t,1);p2=e(t,2);p3=e(t,3);p4=e(t,4);%提取单元内点的编号到p1,p2,p3,p4
        k=k+stiffness(E,NU,h,x1(p2),y1(p2),x1(p3),y1(p3),x1(p4),y1(p4),x1(p1),y1(p1));
        K=assemble(K,k,p2,p3,p4,p1);
    end
end
% 利用K*u=f求解位移矩阵 改一置零法
% 刚度矩阵K1,将位移为0的对应刚度矩阵对角线置1，其余置0
K1=K;
d = size(K1,1);
for i=1:11*2
    K1(i,i)=1;
    for j=i+1:d
        K1(j,i)=0;
        K1(i,j)=0;
    end
end
% 载荷矩阵f,施加Y方向向下集中力载荷20N
f = zeros(d,1);
f(3302)=-20;
% 解方程，位移矩阵u是每个点u、v的组装
u = K1\f;

%% 变形后的图（位移）
%将u分为x，y方向上的位移
for i=1:11*151
    u1(i)=u(2*i-1);
    u2(i)=u(2*i);
end
% 坐标值加上位移值=位移变形后的图
for i=1:11*151
    x3(i)=x1(i)+u1(i);
    y3(i)=y1(i)+u2(i);
end

% 绘制位移图
figure
hold on
% 竖线
for i=1:151
    for j=1:10
        plot([x3(j+(i-1)*11),x3(j+1+(i-1)*11)],[y3(j+(i-1)*11),y3(j+1+(i-1)*11)],'r');
    end
end
% 横线
for i=1:150
    for j=1:11
        plot([x3(j+(i-1)*11),x3(j+i*11)],[y3(j+(i-1)*11),y3(j+i*11)],'r');
    end
end
xlabel('x轴');ylabel('y轴'); title('变形后图形'); 
%% 绘制位移云图(U1)
figure
hold on
for i=1:10*150
    j=e(i,:);
    fill(x3(j),y3(j),u1(j),'FaceColor','interp');
end
shading interp;
colorbar;
colormap jet;
axis equal;
xlabel('x轴');ylabel('y轴'); title('变形后图形上的U1位移云图'); 

%% 绘制位移云图(U2)
figure
hold on
for i=1:10*150
    j=e(i,:);
    fill(x3(j),y3(j),u2(j),'FaceColor','interp');
end
shading interp;
colorbar;
colormap jet;
axis equal;
xlabel('x轴');ylabel('y轴'); title('变形后图形上的U2位移云图'); 

%% RF=K*u;计算反力
RF=K*u;
for i=1:11*151
    RF1(i)=RF(2*i-1);
    RF2(i)=RF(2*i);
end
for i=1:151
    for j=1:11
        RF11(j,i)=RF1(j+(i-1)*11);
        RF22(j,i)=RF2(j+(i-1)*11);
    end
end
%% 计算单元应力,计算主应力
% 单元应力
stress=zeros(10*150,3);
strain=zeros(10*150,3);
for j=1:10
    for i=1:150
        t=i+(j-1)*150;
        %提取单元内点的编号到p1,p2,p3,p4
        p1=e(t,1);p2=e(t,2);p3=e(t,3);p4=e(t,4);
        %各单元四个点的位移
        uel=[u1(p2);u2(p2);u1(p3);u2(p3);u1(p4);u2(p4);u1(p1);u2(p1)];
%            uel=[u1(p1);u2(p1);u1(p2);u2(p2);u1(p3);u2(p3);u1(p4);u2(p4)];
        %各单元中心的应力、应变
        [stress(t,:),strain(t,:)]=stressandstrain(E,NU,x1(p2),y1(p2),x1(p3),y1(p3),x1(p4),y1(p4),x1(p1),y1(p1),uel);
%          [stress(t,:),strain(t,:)]=stressandstrain(E,NU,x1(p1),y1(p1),x1(p2),y1(p2),x1(p3),y1(p3),x1(p4),y1(p4),uel);
    end
end


% 计算主应力大小，方向角
sigma=zeros(10*150,3);
for j=1:10
    for i=1:150
        t=i+(j-1)*150;
        sigma(t,:)=PStresses(stress(t,:));
    end
end


%% 绘制主应力云图前数据处理：节点处应力等于共用该节点单元的应力的平均
com=zeros(11*151,5);%com第一列存储有几个单元共用该点，后四列存储单元编号（不足四列的为0）
for i=1:10*150
    com(e(i,1),1)=com(e(i,1),1)+1;
    com(e(i,1),com(e(i,1),1)+1)=i;
    com(e(i,2),1)=com(e(i,2),1)+1;
    com(e(i,2),com(e(i,2),1)+1)=i;
    com(e(i,3),1)=com(e(i,3),1)+1;
    com(e(i,3),com(e(i,3),1)+1)=i;
    com(e(i,4),1)=com(e(i,4),1)+1;
    com(e(i,4),com(e(i,4),1)+1)=i;
end
%提取sigma第一列
for i=1:150*10
    sigma1(i)=sigma(i,1);
    sigma2(i)=sigma(i,2);
    sigma3(i)=sigma(i,3);
end
% 计算节点处应力值（是周边单元应力的平均值）
sigma1=[sigma1,0];
sigma2=[sigma2,0];
sigma3=[sigma3,0];
for i=1:11*151
    for j=2:5
%         由于调用sigma1时下标不能为0，所以将sigma1后增加一个0，
%         将com(i,j)==0时的sigma1连接它即可解决问题
        if com(i,j)==0 
            com(i,j)=10*150+1;
        end
    end
    %各点的第一主应力
    sigmanode1(i)=(sigma1(com(i,2))+sigma1(com(i,3))+sigma1(com(i,4))+sigma1(com(i,5)))/com(i,1);
    %各点的第二主应力
    sigmanode2(i)=(sigma2(com(i,2))+sigma2(com(i,3))+sigma2(com(i,4))+sigma2(com(i,5)))/com(i,1);
end

%% 绘制第一主应力云图
% 利用fill函数就可以得到四边形的stress云图。利用这个思路，
% 我们在得到有限元计算的所有节点的应力值后，可以对单元进行每
% 个子单元的应力云图绘制，循环完所有的单元后就可以得到整体区域的应力云图了。
figure
hold on
for i=1:10*150
    j=e(i,:);
    fill(x1(j),y1(j),sigmanode1(j),'FaceColor','interp');
end
shading interp;% 去掉网格，使云图更平滑平滑
colorbar;
colormap jet;
axis equal;
xlabel('x轴');ylabel('y轴'); title('第一主应力云图'); 
caxis([-10 50]);


%% 绘制第二主应力云图
figure
hold on
for i=1:10*150
    j=e(i,:);
    fill(x1(j),y1(j),sigmanode2(j),'FaceColor','interp');
end
shading interp;
colorbar;
colormap jet;
axis equal;
xlabel('x轴');ylabel('y轴'); title('第二主应力云图'); 
caxis([-20 20]);

%% 绘制mise应力、应变云图前的数据处理
for i=1:150*10
    stress1(i)=stress(i,1);
    stress2(i)=stress(i,2);
    stress3(i)=stress(i,3);
    strain1(i)=strain(i,1);
    strain2(i)=strain(i,2);
    strain3(i)=strain(i,3);
end
% 计算节点处应力值（是周边单元应力的平均值）
stress1=[stress1,0];
stress2=[stress2,0];
stress3=[stress3,0];
strain1=[strain1,0];
strain2=[strain2,0];
strain3=[strain3,0];
for i=1:11*151
    for j=2:5
%         由于调用sigma1时下标不能为0，所以将sigma1后增加一个0，
%         将com(i,j)==0时的sigma1连接它即可解决问题
        if com(i,j)==0 
            com(i,j)=10*150+1;
        end
    end
    %各点的stress1平均值
    stressnode1(i)=(stress1(com(i,2))+stress1(com(i,3))+stress1(com(i,4))+stress1(com(i,5)))/com(i,1);
    %各点的stress2平均值
    stressnode2(i)=(stress2(com(i,2))+stress2(com(i,3))+stress2(com(i,4))+stress2(com(i,5)))/com(i,1);
    %各点的stress3平均值
    stressnode3(i)=(stress3(com(i,2))+stress3(com(i,3))+stress3(com(i,4))+stress3(com(i,5)))/com(i,1);
    %各点的mise应力
    mise(i)=(((stressnode1(i)-stressnode2(i))^2+(stressnode2(i)-stressnode3(i))^2+(stressnode3(i)-stressnode1(i))^2)/2)^0.5;
    %各点的strain1平均值
    strainnode1(i)=(strain1(com(i,2))+strain1(com(i,3))+strain1(com(i,4))+strain1(com(i,5)))/com(i,1);
    %各点的strain2平均值
    strainnode2(i)=(strain2(com(i,2))+strain2(com(i,3))+strain2(com(i,4))+strain2(com(i,5)))/com(i,1);
    %各点的strain3平均值
    strainnode3(i)=(strain3(com(i,2))+strain3(com(i,3))+strain3(com(i,4))+strain3(com(i,5)))/com(i,1);
    %各点的应变
    strain0(i)=(((strainnode1(i)-strainnode2(i))^2+(strainnode2(i)-strainnode3(i))^2+(strainnode3(i)-strainnode1(i))^2)/2)^0.5;
end


%% 绘制mise应力云图
figure
hold on
for i=1:10*150
    j = e(i,:);
    fill(x1(j),y1(j),mise(j),'FaceColor','interp');
end
shading interp;% 去掉网格，使云图更平滑平滑
colorbar;
colormap jet;
axis equal;
xlabel('x轴');ylabel('y轴'); title('mise应力云图'); 
caxis([-10 50]);
%% 绘制应变云图
figure
hold on
for i=1:10*150
    j=e(i,:);
    fill(x1(j),y1(j),strain0(j),'FaceColor','interp');
end
shading interp;% 去掉网格，使云图更平滑平滑
colorbar;
colormap jet;
axis equal;
xlabel('x轴');ylabel('y轴'); title('应变云图'); 