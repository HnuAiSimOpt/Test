function [von_mises]=fevon_mises(estress_x,estress_y,estress_z,estress_xy,estress_xz,estress_yz)
s=[estress_x,estress_y,estress_z,estress_xy,estress_xz,estress_yz];
M=[1,-0.5,-0.5,0,0,0;
    -0.5,1,-0.5,0,0,0;
    -0.5,-0.5,1,0,0,0;
    0,0,0,3,0,0;
    0,0,0,0,3,0;
    0,0,0,0,0,3];
von_mises=(s*M*s')^0.5;
