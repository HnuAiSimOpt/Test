function [shapeq8,dhdrq8,dhdsq8,dhdtq8]=feisoq8(rvalue,svalue,tvalue)
%Purpose: 
%compute isoparametric four-node quadilateral shape functions
%and their derivatves at the selected (integration) point
%in terms of the natural coordinate 
%Synopsis:
%[shapeq8,dhdrq8,dhdsq8]=feisoq8(rvalue,svalue,tvalue)  
%Variable Description: 
%shapeq8 - shape functions for eight-node element
%dhdrq8 - derivatives of the shape functions w.r.t. r
%dhdsq8 - derivatives of the shape functions w.r.t. s
%dhdtq8 - derivatives of the shape functions w.r.t. t
%rvalue - r coordinate value of the selected point   
%Notes:
%1st node at (-1,-1,-1),2nd node at (1,-1,-1),3rd node at (1,1,-1),4th node at (-1,1,-1)
%5st node at (-1,-1,1),6nd node at (1,-1,1),7rd node at (1,1,1),8th node at (-1,1,1)
% shape functions
shapeq8(1)=0.125*(1-rvalue)*(1-svalue)*(1-tvalue);
shapeq8(2)=0.125*(1+rvalue)*(1-svalue)*(1-tvalue);
shapeq8(3)=0.125*(1+rvalue)*(1+svalue)*(1-tvalue);
shapeq8(4)=0.125*(1-rvalue)*(1+svalue)*(1-tvalue);
shapeq8(5)=0.125*(1-rvalue)*(1-svalue)*(1+tvalue);
shapeq8(6)=0.125*(1+rvalue)*(1-svalue)*(1+tvalue);
shapeq8(7)=0.125*(1+rvalue)*(1+svalue)*(1+tvalue);
shapeq8(8)=0.125*(1-rvalue)*(1+svalue)*(1+tvalue);
%derivatives r
dhdrq8(1)=-0.125*(1-svalue)*(1-tvalue);
dhdrq8(2)=0.125*(1-svalue)*(1-tvalue);
dhdrq8(3)=0.125*(1+svalue)*(1-tvalue);
dhdrq8(4)=-0.125*(1+svalue)*(1-tvalue);
dhdrq8(5)=-0.125*(1-svalue)*(1+tvalue);
dhdrq8(6)=0.125*(1-svalue)*(1+tvalue);
dhdrq8(7)=0.125*(1+svalue)*(1+tvalue);
dhdrq8(8)=-0.125*(1+svalue)*(1+tvalue);
%derivatives s
dhdsq8(1)=-0.125*(1-rvalue)*(1-tvalue);
dhdsq8(2)=-0.125*(1+rvalue)*(1-tvalue);
dhdsq8(3)=0.125*(1+rvalue)*(1-tvalue);
dhdsq8(4)=0.125*(1-rvalue)*(1-tvalue);
dhdsq8(5)=-0.125*(1-rvalue)*(1+tvalue);
dhdsq8(6)=-0.125*(1+rvalue)*(1+tvalue);
dhdsq8(7)=0.125*(1+rvalue)*(1+tvalue);
dhdsq8(8)=0.125*(1-rvalue)*(1+tvalue);
%derivatives t
dhdtq8(1)=-0.125*(1-rvalue)*(1-svalue);
dhdtq8(2)=-0.125*(1+rvalue)*(1-svalue);
dhdtq8(3)=-0.125*(1+rvalue)*(1+svalue);
dhdtq8(4)=-0.125*(1-rvalue)*(1+svalue);
dhdtq8(5)=0.125*(1-rvalue)*(1-svalue);
dhdtq8(6)=0.125*(1+rvalue)*(1-svalue);
dhdtq8(7)=0.125*(1+rvalue)*(1+svalue);
dhdtq8(8)=0.125*(1-rvalue)*(1+svalue);