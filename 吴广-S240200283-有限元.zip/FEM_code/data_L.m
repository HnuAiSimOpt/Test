clear all
clc
nnode=425;
nel=256;
[a]=xlsread('L����.xlsx');
x0=a(:,11:13);
x0=round(x0,5);
nodes=a(1:nel,2:9);
bcdof_nodes=a(1:25,14);
fload_nodes=a(1:25,15);
num=size(bcdof_nodes,1);
num1=size(fload_nodes,1);
bcdof=[];
bcval=[];
bcfload=[];
for i=1:num
    bcdof=[bcdof (bcdof_nodes(i,1)-1)*3+1 (bcdof_nodes(i,1)-1)*3+2 (bcdof_nodes(i,1)-1)*3+3];
    bcval=[bcval 0 0 0];
end
for i=1:num1
    bcfload=[bcfload (fload_nodes(i,1)-1)*3+2];
end
save data_L x0 nodes bcdof bcval bcfload;