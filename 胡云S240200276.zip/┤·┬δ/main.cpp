//ƽ�����ǵ�Ԫ����Ԫ//
#include"stdio.h"
#include"math.h"
#include "matlib.h"
#include "draw.h"
#include <process.h>

double** dmake(int m,int n)
{
	double **a;
	a=new double *[m];
	for(int i=0;i<m;i++)
		a[i]=new double[n];
	return a;
}
void ddelete(double **a,int m,int n)
{
	for(int i=0;i<m;i++)
		delete a[i];
	delete a;
}

int** imake(int m,int n)
{
	int **a;
	a=new int *[m];
	for(int i=0;i<m;i++)
		a[i]=new int[n];
	return a;
}
void idelete(int **a,int m,int n)
{
	for(int i=0;i<m;i++)
		delete a[i];
	delete a;
}

int num;
float *xx,*yy;

float jisuan(bool bl,int line,int row,float chang,float gao,float ee,float vv,float h,float q,int iffix[])
{
	//��ʼ����
	//	double k[20][20],r[20];
	//	float x[10],y[10],ee,e1,vv,h,q,dip[20];
	float e1,e2;
	//	float e2,str[3][8],strn[7][10];
	int iee;//ie[8][3];
	int npoin;
	float b[3],c[3],area;
	//	int in1,ir[20],ind,id[20],iffix[2];
	int in1,ind;
	int i,j,m,nn,n,add;
	float a,tt;
	int nmax,nmax1;
	float smax,smax1;
	int ii;
	
	FILE *fp,*fp2,*fp3,*fp4,*fp5;
	//�������ݣ�
	
	fp=fopen("data.txt","w");
	fp2=fopen("coord.txt","w");
	fp3=fopen("ie.txt","w");
	fp4=fopen("ir.txt","w");
	fp5=fopen("iffix.txt","w");
	//printf("please input the data.\n");
	npoin=line*row;
	iee=(row-1)*2*(line-1);
	//printf("the number of elements:%d\n",npoin);
	//printf("the number of elements:%d\n",iee);
	double **k,**str,**strn;
	k=dmake(2*npoin,2*npoin);
	str=dmake(3,iee);
	strn=dmake(7,npoin);
	int **ie;
	ie=imake(iee,3);
	double *r=new double[2*npoin];
	float *x=new float[npoin];
	float *y=new float[npoin];
	float *dip=new float[2*npoin];
	int *ir=new int[line];
	int *id=new int[line];
	
	for(ii=0;ii<npoin;ii++)
	{
		//fscanf(fp2,"%f%f",&x[ii],&y[ii]);
		x[ii]=int(ii/line)*chang/(row-1);
		y[ii]=(ii%line)*gao/(line-1);
		if(bl)fprintf(fp2,"%f %f\n",x[ii],y[ii]);
	}
	
	num=4*(line-1)+2*(row-1)-2;
	xx=new float[num];
	yy=new float[num];
	for(i=2,ii=0;i<=line;i++,ii++)
	{
		xx[2*ii]=x[i-1];
		yy[2*ii]=y[i-1];
		for(j=0;j*(line-1)+i<row;j++,ii++)
		{
			xx[2*ii+1]=x[(j*(line-1)+i-1)*line];
			xx[2*ii+2]=x[(j*(line-1)+i)*line-1];
			yy[2*ii+1]=y[(j*(line-1)+i-1)*line];
			yy[2*ii+2]=y[(j*(line-1)+i)*line-1];
		}
		xx[2*ii+1]=x[npoin-(row-((j-1)*(line-1)+i))-1];
		xx[2*ii+2]=x[(npoin-(row-((j-1)*(line-1)+i))-1)%line];
		yy[2*ii+1]=y[npoin-(row-((j-1)*(line-1)+i))-1];
		yy[2*ii+2]=y[(npoin-(row-((j-1)*(line-1)+i))-1)%line];
		ii++;
		xx[2*ii+1]=x[0];
		yy[2*ii+1]=y[0];
	}
	/*for(i=0;i<num;i++)
	printf("%f %f\n",xx[i],yy[i]);
	return;*/
	
	//��������
	//printf("reading ie[i][j]...\n");
	for(ii=1;ii<=iee;ii++)
	{
		if(ii%2!=0)
		{
			ie[ii-1][0]=ii/((line-1)*2)*line+1+(ii%((line-1)*2))/2;
			ie[ii-1][1]=ii/((line-1)*2)*line+line+1+(ii%((line-1)*2))/2;
			ie[ii-1][2]=ii/((line-1)*2)*line+2+(ii%((line-1)*2))/2;
		}
		else
		{
			ie[ii-1][0]=(ii-1)/((line-1)*2)*line+2+((ii-1)%((line-1)*2))/2;
			ie[ii-1][1]=(ii-1)/((line-1)*2)*line+line+1+((ii-1)%((line-1)*2))/2;
			ie[ii-1][2]=(ii-1)/((line-1)*2)*line+line+2+((ii-1)%((line-1)*2))/2;
		}
		if(bl)fprintf(fp3,"%i %i %i\n",ie[ii-1][0],ie[ii-1][1],ie[ii-1][2]);
	}
	//�ܸո��㣻
	for(i=0;i<2*npoin;i++)
	{
		for(j=0;j<2*npoin;j++)
		{
			k[i][j]=0;
		}
	}
	//����iee��Ԫ�����
	for(i=0;i<iee;i++)
	{
		float x1,x2,x0,y1,y2,y0;
		x0=x[ie[i][0]-1];
		x1=x[ie[i][1]-1];
		x2=x[ie[i][2]-1];
		
		y0=y[ie[i][0]-1];
		y1=y[ie[i][1]-1];
		y2=y[ie[i][2]-1];
		
		b[0]=y1-y2;
		b[1]=y2-y0;
		b[2]=y0-y1;
		
		c[0]=x2-x1;
		c[1]=x0-x2;
		c[2]=x1-x0;
		
		area=(b[0]*c[1]-b[1]*c[0])/2.0;
		e1=ee/(4.0*(1.0-pow(vv,2))*area);
		/*printf("the area:%f\n",area);
		printf("the e1:%f\n",e1);
		printf("the number of ie:%i\n",i+1);
		for(j=0;j<3;j++)
		{
		printf("B%i:%f\n",j,b[j]);
		printf("C%i:%f\n",j,c[j]);
	}*/
		//�γ��ܸգ�
		for(j=0;j<3;j++)
		{
			for(m=0;m<3;m++)
			{
				if(i==0)
				{
					
					
					k[(ie[i][j]-1)*2][(ie[i][m]-1)*2]=e1*(b[j]*b[m]+(1.0-vv)*c[j]*c[m]/2.0);
					
					
					k[(ie[i][j]-1)*2][(ie[i][m]-1)*2+1]=e1*(vv*b[j]*c[m]+(1.0-vv)*c[j]*b[m]/2.0);
					
					
					k[(ie[i][j]-1)*2+1][(ie[i][m]-1)*2]=e1*(vv*c[j]*b[m]+(1.0-vv)*b[j]*c[m]/2.0);
					
					
					k[(ie[i][j]-1)*2+1][(ie[i][m]-1)*2+1]=e1*(c[j]*c[m]+(1.0-vv)*b[j]*b[m]/2.0);
				}
				else
				{
					
					
					k[(ie[i][j]-1)*2][(ie[i][m]-1)*2]=k[(ie[i][j]-1)*2][(ie[i][m]-1)*2]+e1*(b[j]*b[m]+(1.0-vv)*c[j]*c[m]/2.0);
					
					
					k[(ie[i][j]-1)*2][(ie[i][m]-1)*2+1]=k[(ie[i][j]-1)*2][(ie[i][m]-1)*2+1]+e1*(vv*b[j]*c[m]+(1.0-vv)*c[j]*b[m]/2.0);
					
					
					k[(ie[i][j]-1)*2+1][(ie[i][m]-1)*2]=k[(ie[i][j]-1)*2+1][(ie[i][m]-1)*2]+e1*(vv*c[j]*b[m]+(1.0-vv)*b[j]*c[m]/2.0);
					
					
					k[(ie[i][j]-1)*2+1][(ie[i][m]-1)*2+1]=k[(ie[i][j]-1)*2+1][(ie[i][m]-1)*2+1]+e1*(c[j]*c[m]+(1.0-vv)*b[j]*b[m]/2.0);
				}
			}
		}
	}
	/*for(i=0;bl&&i<2*npoin;i++){
		for(j=0;j<2*npoin;j++){
			fprintf(fp,"%.0f",k[i][j]);
			if(j==2*npoin-1)fprintf(fp,"\n");
		}
	}
	if(bl)fprintf(fp,"\n");*/
	//�Ҷ��غ����㣻
	for(i=0;i<2*npoin;i++){
		r[i]=0;
	}
	//���غɣ�
	//printf("total number of loads:\n");
	//printf("node number of loads:\n");
	for(ii=0,i=npoin-line+1;i<=npoin;i++,ii++){
		ir[ii]=i;
		if(bl)fprintf(fp4,"%i\n",ir[ii]);
	}
	
	
	q=q/line;
	//printf("q=%f",q);
	//
	//���ؽڵ���
	in1=line;
	for(i=0;i<in1;i++){
		r[2*ir[i]-2]=iffix[0]*q;
		r[2*ir[i]-1]=iffix[1]*q;
	}
	/*for(i=0;i<2*npoin;i++){
	printf("r[%i]:%.2f\n",i,r[i]);
	}*/
	//λ�Ʊ߽�������
	//printf("the number of the KNOWN displacements:\n");
	//��֪λ�ƽڵ�
	ind=line;
	//printf("node NUMBER of the KNOWN displacements:\n");
	for(i=0;i<ind;i++)
	{
		id[i]=i+1;
		if(bl)fprintf(fp5,"%d\n",id[i]);
	}
	//printf("please input the KNOWN displacement:\n");
	for(i=0;i<ind;i++)
	{
		dip[2*id[i]-2]=0;
		dip[2*id[i]-1]=0;
		//fscanf(fp1,"%f",&dip[2*id[i]-2]);
		//fscanf(fp1,"%f",&dip[2*id[i]-1]);
		//printf("dip[id[i]]:  %f,%f",dip[2*id[i]-1],dip[2*id[i]]);
	}
	//�ô�����;
	for(i=0;i<ind;i++)
	{
		k[2*id[i]-2][2*id[i]-2]=1.0e+20;
		k[2*id[i]-1][2*id[i]-1]=1.0e+20;
		r[2*id[i]-2]=dip[2*id[i]-2]*1.0e+20;
		r[2*id[i]-1]=dip[2*id[i]-1]*1.0e+20;
	}
	//��˹����Ԫ����ⷽ����;
	for(n=0;n<2*npoin-1;n++)
	{
		for(i=n+1;i<2*npoin;i++)
		{
			if(fabs(k[i][n])>=fabs(k[n][n]))
			{
				tt=r[n];
				r[n]=r[i];
				r[i]=tt;
				for(j=n;j<2*npoin;j++)
				{
					tt=k[n][j];
					k[n][j]=k[i][j];
					k[i][j]=tt;
				}
			}
		}
		for(i=n+1;i<2*npoin;i++)
		{
			for(j=n+1;j<2*npoin;j++)
			{
				k[i][j]=k[i][j]-(k[i][n]/k[n][n])*k[n][j];
			}
			r[i]=r[i]-(k[i][n]/k[n][n])*r[n];
			k[i][n]=0.0;
		}
	}
	for(i=0;bl&&i<2*npoin;i++)
	{
		fprintf(fp,"r[%i]:%e\n",i,r[i]);
	}
	if(bl)fprintf(fp,"\n");
/*	for(i=0;bl&&i<2*npoin;i++)
	{
		for(j=0;j<2*npoin;j++)
		{
			fprintf(fp,"%.0f",k[i][j]);
			if(j==7)fprintf(fp,"\n");
		}
	}
	if(bl)fprintf(fp,"\n");*/
	//�ش�
	for(i=2*npoin-1;i>=0;i--)
	{
		a=0.0;
		for(j=i+1;j<2*npoin;j++)
		{
			a=a+k[i][j]*dip[j];
		}
		//printf("a=%f\n",a);
		dip[i]=(r[i]-a)/k[i][i];
	}
	if(bl)fprintf(fp,"the DISPLACEMENT is:\n");
	for(i=0;bl&&i<2*npoin;i++)
	{
		fprintf(fp,"dip[%i]=%e\n",i,dip[i]);
	}
	if(bl)fprintf(fp,"\n");
	//��ԪӦ�����㣻
	for(i=0;i<3;i++)
	{
		for(j=0;j<iee;j++)
		{
			str[i][j]=0;
		}
	}
	//����Ӧ����
	for(i=0;i<iee;i++)
	{
		b[0]=y[ie[i][1]-1]-y[ie[i][2]-1];
		b[1]=y[ie[i][2]-1]-y[ie[i][0]-1];
		b[2]=y[ie[i][0]-1]-y[ie[i][1]-1];
		c[0]=x[ie[i][2]-1]-x[ie[i][1]-1];
		c[1]=x[ie[i][0]-1]-x[ie[i][2]-1];
		c[2]=x[ie[i][1]-1]-x[ie[i][0]-1];
		
		area=(b[0]*c[1]-b[1]*c[0])/2.0;
		e2=ee/(2*area*(1-pow(vv,2)));
		for(m=0;m<3;m++)
		{
			
			
			str[0][i]=str[0][i]+e2*(b[m]*dip[(ie[i][m]-1)*2]+vv*c[m]*dip[(ie[i][m]-1)*2+1]);
			
			
			str[1][i]=str[1][i]+e2*(vv*b[m]*dip[(ie[i][m]-1)*2]+c[m]*dip[(ie[i][m]-1)*2+1]);
			
			
			str[2][i]=str[2][i]+e2*(1-vv)*(c[m]*dip[(ie[i][m]-1)*2]+b[m]*dip[(ie[i][m]-1)*2+1])/2.0;
		}
	}
	if(bl)fprintf(fp,"the STRESS is:\n");
	for(i=0;bl&&i<iee;i++)
	{
		for(j=0;j<3;j++)
		{
			fprintf(fp,"str[%i][%i]=%.4f\n",j,i,str[j][i]);
		}
		fprintf(fp,"\n");
	}
	//���ڵ�Ӧ������
	for(i=0;i<7;i++){
		for(j=0;j<npoin;j++){strn[i][j]=0;
		}
	}
	//������ڵ�Ӧ��;
	add=0;
	nmax=0;
	nmax1=0;
	smax=0;
	smax1=0;
	if(bl)fprintf(fp,"the STRESS of every NODE is:\n");
	for(i=0;i<npoin;i++){
		nn=0;
		for(j=0;j<iee;j++){
			for(m=0;m<3;m++){
				if(ie[j][m]-1==i){
					nn++;
					add=1;
				}
			}
			if(add==1){
				add=0;
				strn[0][i]=strn[0][i]+str[0][j];
				strn[1][i]=strn[1][i]+str[1][j];
				strn[2][i]=strn[2][i]+str[2][j];
			}
		}
		strn[0][i]=strn[0][i]/nn;
		strn[1][i]=strn[1][i]/nn;
		strn[2][i]=strn[2][i]/nn;
		if(bl){
			fprintf(fp,"Strn[0][%i]=%e\n",i,strn[0][i]);
			fprintf(fp,"Strn[1][%i]=%e\n",i,strn[1][i]);
			fprintf(fp,"Strn[2][%i]=%e\n",i,strn[2][i]);}
	}
	
    float result=0.0;
	if(!bl)result=dip[(line/2+1)*row*2-1];
	delete x;delete y;delete r;delete dip;delete ir;delete id;
	ddelete(k,2*npoin,2*npoin);
	ddelete(str,3,iee);
	ddelete(strn,7,npoin);
	fclose(fp);
	fclose(fp2);
	fclose(fp3);
	fclose(fp4);
	fclose(fp5);
	return result;
}

void main()
{
	int line,row,iffix[2];
	float chang,gao,ee,vv,h,q;
	FILE *fp1;
	fp1=fopen("init.dat","r");
	fscanf(fp1,"%i",&line);
	fscanf(fp1,"%i",&row);
	fscanf(fp1,"%f",&chang);
	fscanf(fp1,"%f",&gao);
	//	printf("the number of elements:\n");
	//fscanf(fp1,"%i",&iee);
	//printf("E:\n");
	fscanf(fp1,"%f",&ee);
	//printf("Poisson Rate:\n");
	fscanf(fp1,"%f",&vv);
	//printf("Poisson Rate:%f\n",vv);
	//printf("freedom of nodes which have loads...\n");
	fscanf(fp1,"%i",&iffix[0]);
	fscanf(fp1,"%i",&iffix[1]);
	//	printf("value of p:\n");
	fscanf(fp1,"%f",&q);
	//printf("value of h:\n");
	fscanf(fp1,"%f",&h);
	fclose(fp1);

	printf("�Ƿ��е�λ������<Y/N>:");
	char s;
	scanf("%c",&s);
    if(s=='Y'||s=='y')
	{printf("�������12�����ݣ����Ժ�\n");
	int l,r,n=12;
	float mid[12];
	for(int j=0;j<n;j++)
	{
		l=5+4*j;
		r=3+2*j;
		mid[j]=jisuan(false,l,r,chang,gao,ee,vv,h,q,iffix);
		printf("��%d������%4d�ڵ�������,�е�λ��:%f\n",j+1,l*r,mid[j]);
	}
	initM(MATCOM_VERSION);
	Mm x=zeros(1,n);
	Mm y=zeros(1,n);
	for(int i=1;i<=n;i++)x(i)=(5+4*(i-1))*(3+2*(i-1));
	for(i=1;i<=n;i++)y(i)=mid[i-1];
	draw(x,y);
	exitM();
	}
	jisuan(true,line,row,chang,gao,ee,vv,h,q,iffix);
	getchar();
	printf("�Ƿ񻭵�Ԫ����<Y/N>:");
	scanf("%c",&s);
    if(s=='Y'||s=='y')
	{
		initM(MATCOM_VERSION);
		Mm mx=zeros(1,num);
		Mm my=zeros(1,num);
		for(int i=1;i<=num;i++)mx(i)=xx[i-1];
		for(i=1;i<=num;i++)my(i)=yy[i-1];
		draw(mx,my);
		exitM();
	}
	delete xx,yy;
}