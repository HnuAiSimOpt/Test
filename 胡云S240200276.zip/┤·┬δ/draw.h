#ifndef __draw_h
#define __draw_h

Mm draw(Mm x, Mm y);

#endif // __draw_h
