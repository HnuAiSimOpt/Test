function draw(x,y)
plot(x,y)
