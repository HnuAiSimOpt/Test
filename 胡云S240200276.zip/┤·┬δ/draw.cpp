  #include "matlib.h"
  #pragma hdrstop
  
  #include "draw.h"
  
  
  Mm draw(Mm x, Mm y) {
    begin_scope
    x.setname("x"); y.setname("y"); 
    #line 1 "d:/����Ԫ/������/draw.m"
    call_stack_begin;
    #line 1 "d:/����Ԫ/������/draw.m"
    // nargin, nargout entry code
    double old_nargin=nargin_val; if (!nargin_set) nargin_val=2.0;
    nargin_set=0;
    double old_nargout=nargout_val; if (!nargout_set) nargout_val=0.0;
    nargout_set=0;
    
    // translated code
    
    #line 2 "d:/����Ԫ/������/draw.m"
_   display( plot((CL(x),y)) );
    
    call_stack_end;
    
    // nargin, nargout exit code
    nargin_val=old_nargin; nargout_val=old_nargout;
    
    // function exit code
    x.setname(NULL); y.setname(NULL); 
    
    return x_M;
    end_scope
  }
  
  
