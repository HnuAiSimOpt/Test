function K_global = assembleK(K_global, Ke, edof)
    % ���ý��׷���װȫ�ָնȾ���
    global dofPerElem
    for i = 1:dofPerElem
        if edof(i) ~= 0
            for j = 1:dofPerElem
                if edof(j) ~= 0
                    K_global(edof(i), edof(j)) = K_global(edof(i), edof(j)) + Ke(i,j);
                end
            end
        end
    end
end