function [B, edof, area] = getT3Elem(elem)
    % ���㵥ԪӦ��-λ�ƾ��󡢵�Ԫ���ɶȱ�ż����
    global nodeCoords elemNodes freedomMat dofPerNode nodesPerElem
    idx = elemNodes(elem, :);  % ��Ԫ�ڵ���
    x = nodeCoords(idx, 1);
    y = nodeCoords(idx, 2);
    % ���㵥Ԫ���
    area = 0.5 * det([1, x(1), y(1); 1, x(2), y(2); 1, x(3), y(3)]);
    
    % ���� B ����
    m11 = (x(2)*y(3) - x(3)*y(2)) / (2 * area);
    m21 = (x(3)*y(1) - x(1)*y(3)) / (2 * area);
    m31 = (x(1)*y(2) - x(2)*y(1)) / (2 * area);
    m12 = (y(2) - y(3)) / (2 * area);
    m22 = (y(3) - y(1)) / (2 * area);
    m32 = (y(1) - y(2)) / (2 * area);
    m13 = (x(3) - x(2)) / (2 * area);
    m23 = (x(1) - x(3)) / (2 * area);
    m33 = (x(2) - x(1)) / (2 * area);
    
    B = [ m12,    0, m22,    0, m32,    0;
           0,  m13,   0, m23,   0, m33;
         m13, m12, m23, m22, m33, m32 ];
    
    % ��Ԫ���ɶȱ������ edof
    edof = zeros(1, dofPerNode * nodesPerElem);
    cnt = 0;
    for k = 1:nodesPerElem
        for j = 1:dofPerNode
            cnt = cnt + 1;
            edof(cnt) = freedomMat(elemNodes(elem, k), j);
        end
    end
end