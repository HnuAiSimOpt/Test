function fullDisp = recoverNodalDisplacement(U_free, freedomMat)
    % �ָ�ȫ�ڵ�λ�ƣ�����Լ���ڵ㣩
    nNodes = size(freedomMat,1);
    dofPN = size(freedomMat,2);
    fullDisp = zeros(nNodes, dofPN);
    for i = 1:nNodes
        for j = 1:dofPN
            if freedomMat(i,j) == 0
                fullDisp(i,j) = 0;
            else
                fullDisp(i,j) = U_free(freedomMat(i,j));
            end
        end
    end
end