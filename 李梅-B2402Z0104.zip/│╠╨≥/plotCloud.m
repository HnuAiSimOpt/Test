function plotCloud(figTitle, coords, elems, data)
    % ������ͼ����
    figure('Name', figTitle);
    title(figTitle);
    % ���� colormap
    myCMap = 1/255 * [0,0,255; 0,93,255; 0,185,255; 0,255,232;
                      0,255,139; 0,255,46; 46,255,0; 139,255,0;
                      232,255,0; 255,185,0; 255,93,0; 255,0,0];
    for e = 1:size(elems,1)
        nodes = elems(e,:);
        patch(coords(nodes,1), coords(nodes,2), data(nodes), 'EdgeColor', 'none');
    end
    colormap(myCMap);
    caxis([min(data), max(data)]);
    ticks = linspace(min(data), max(data), 13);
    colorbar('ytick', ticks, 'Location', 'westoutside');
    axis equal; axis on;
end