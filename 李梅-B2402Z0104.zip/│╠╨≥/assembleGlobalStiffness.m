function K_global = assembleGlobalStiffness(thickness)
    % ��װȫ�ָնȾ��󣨽��׷���
    global numElem dofPerElem
    totalDof = evalin('caller', 'max(freedomMat(:))');  % ��ȡ�����ɶ���
    K_global = zeros(totalDof, totalDof);
    for elem = 1:numElem
        [B, edof, area] = getT3Elem(elem);
        Ke = thickness * area * (B' * evalin('caller', 'D_mat') * B);
        K_global = assembleK(K_global, Ke, edof);
    end
end