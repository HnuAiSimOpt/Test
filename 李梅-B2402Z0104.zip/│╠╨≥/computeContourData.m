function [nodeEx, nodeEy, nodeEt, nodeSigX, nodeSigY, nodeTau, nodeSig1, nodeSig2] = computeContourData(elemStrain, elemStress)
    % ����ڵ�ƽ��Ӧ���Ӧ�������ں�����ͼ��
    global numNodes numElem nodesPerElem elemNodes
    nodeEx = zeros(numNodes, 1);  
    nodeEy = zeros(numNodes, 1);  
    nodeEt = zeros(numNodes, 1);
    nodeSigX = zeros(numNodes, 1);  
    nodeSigY = zeros(numNodes, 1);  
    nodeTau = zeros(numNodes, 1);
    nodeSig1 = zeros(numNodes, 1);  
    nodeSig2 = zeros(numNodes, 1);
    
    for n = 1:numNodes
        ex = 0; ey = 0; et = 0;
        sx = 0; sy = 0; tau = 0; count = 0;
        for e = 1:numElem
            if any(elemNodes(e,:) == n)
                count = count + 1;
                ex = ex + elemStrain(e,1);
                ey = ey + elemStrain(e,2);
                et = et + elemStrain(e,3);
                sx = sx + elemStress(e,1);
                sy = sy + elemStress(e,2);
                tau = tau + elemStress(e,3);
            end
        end
        if count > 0
            nodeEx(n) = ex / count;
            nodeEy(n) = ey / count;
            nodeEt(n) = et / count;
            nodeSigX(n) = sx / count;
            nodeSigY(n) = sy / count;
            nodeTau(n)  = tau / count;
            avg = (nodeSigX(n) + nodeSigY(n)) / 2;
            diff = (nodeSigX(n) - nodeSigY(n)) / 2;
            R = sqrt(diff^2 + nodeTau(n)^2);
            nodeSig1(n) = avg + R;
            nodeSig2(n) = avg - R;
        end
    end
end