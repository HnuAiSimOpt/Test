import scipy.linalg as linalg
from matplotlib import cm
from scipy import interpolate
import matplotlib
matplotlib.use('TkAgg')
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

class Element2D():
    def __init__(self, nodesCoor, elementsIndex, xCastNodeIndex, yCastNodeIndex, loadNodeIndex, E=210000, u=0.275,
                 thickness=0.001):
        self.xCastNodeIndex = xCastNodeIndex
        self.yCastNodeIndex = yCastNodeIndex
        self.loadNodeIndex = loadNodeIndex
        self.nodesCoor = np.array(nodesCoor, dtype=np.float64)
        self.elementsIndex = np.array(elementsIndex, dtype=np.int32)
        self.nodeNum = self.nodesCoor.shape[0]
        self.elemNum = self.elementsIndex.shape[0]
        self.K = np.zeros([self.nodeNum * 2, self.nodeNum * 2])
        self.CastKF = None
        self.U = np.zeros([self.nodeNum * 2, 1])
        self.F = np.zeros([self.nodeNum * 2, 1])
        self.E = E
        self.u = u
        self.thickness = thickness
    def ShapeMatrix(self, u, x, y):

        u1 = u[0]
        u2 = u[1]
        n1 = 1/4 * (1 - u1) * (1 - u2)
        n2 = 1/4 * (1 + u1) * (1 - u2)
        n3 = 1/4 * (1 + u1) * (1 + u2)
        n4 = 1/4 * (1 - u1) * (1 + u2)
        Ne = np.array([[n1, 0, n2, 0, n3, 0, n4, 0], [0, n1, 0, n2, 0, n3, 0, n4]], dtype=np.float64)
        xe = np.array([x[0], y[0], x[1], y[1], x[2], y[2], x[3], y[3]], dtype=np.float64).reshape(-1, 1)
        x = np.dot(Ne, xe)
        return Ne, x

    def StrainMatrix(self, u, v, x, y):

        u1 = u
        u2 = v
        n1_u1 = -1/4*(1 - u2)
        n1_u2 = -1/4*(1 - u1)
        n2_u1 = 1/4*(1 - u2)
        n2_u2 = -1/4*(1 + u1)
        n3_u1 = 1/4*(1 + u2)
        n3_u2 = 1/4*(1 + u1)
        n4_u1 = -1/4*(1 + u2)
        n4_u2 = 1/4*(1 - u1)

        m = np.array([[n1_u1, n2_u1, n3_u1, n4_u1],[n1_u2, n2_u2, n3_u2, n4_u2]], dtype=np.float64)
        x = x.reshape(-1)
        y = y.reshape(-1)
        cor = np.transpose(np.array([x, y], dtype=np.float64))
        j = np.dot(m, cor)
        j_det = linalg.det(j)
        j_inv = linalg.inv(j)
        n_xy = np.dot(j_inv, m)
        B = np.zeros([3, 8])
        B[0, 0::2] = n_xy[0, :]
        B[1, 1::2] = n_xy[1, :]
        B[2, 0::2] = n_xy[1, :]
        B[2, 1::2] = n_xy[0, :]
        return B, j_det

    def ElasticMatrix(self, type = "Plane Stress"):
        E = self.E
        u = self.u
        if type == "Plane Strain":
            E = E/(1 - np.power(u, 2))
            u = u/(1-u)
        elif type == "Plane stress":
            pass
        D = E /(1 - np.power(u, 2)) * np.array([[1, u, 0], [u, 1, 0], [0, 0, (1-u)/2]])
        return D

    def GaussionIntegrate(self, order = 2):
        if order == 2:
            w = 1
            sqrt_3 = np.sqrt(3)
            natureInterPoints = np.array([[-1/sqrt_3, -1/sqrt_3, 1/sqrt_3, 1/sqrt_3], [-1/sqrt_3, 1/sqrt_3, -1/sqrt_3, 1/sqrt_3]], dtype=np.float64)
            pointNum = order * order
        return natureInterPoints, w, pointNum

    def CalElemStiffness(self, index, order = 2, type = "Plane Stress"):
        E = self.E
        u = self.u
        thickness = self.thickness
        elemNodeSet = self.elementsIndex[index]
        coor = self.nodesCoor[elemNodeSet, :]
        x = coor[:, 0]
        y = coor[:, 1]
        D = self.ElasticMatrix(type=type)
        if order == 2:
            natureInterPoints, weight, pointNum = self.GaussionIntegrate(order=order)
            k = np.zeros([8, 8], dtype=np.float64)
            for integradeIndex in range(pointNum):
                nx = natureInterPoints[0, integradeIndex]
                ny = natureInterPoints[1, integradeIndex]
                b, j_det = self.StrainMatrix(nx, ny, x, y)
                k = k + weight * weight * np.dot(np.dot(np.transpose(b), D), b) * j_det * thickness
        return k, elemNodeSet

    def StructStiffness(self):
        for i in range(self.elemNum):
            k, elemIndex = self.CalElemStiffness(index = i)
            index = np.zeros(8, dtype=np.int32)
            index[0::2] = elemIndex*2
            index[1::2] = elemIndex * 2 + 1
            self.K[np.ix_(index, index)] = k + self.K[np.ix_(index, index)]

        pass

    def ApplyCast(self):
        xCastNodeIndex = np.sort(self.xCastNodeIndex)
        del_dof = np.sort(np.array([xCastNodeIndex*2, xCastNodeIndex*2+1]).reshape(-1))
        self.CastKF = np.delete(self.CastKF, del_dof, axis=0)
        self.CastKF = np.delete(self.CastKF, del_dof, axis=1)

    def SolveFEM(self):
        xCastNodeIndex = np.sort(self.xCastNodeIndex)
        del_dof = np.sort(np.array([xCastNodeIndex*2, xCastNodeIndex*2+1]).reshape(-1))
        self.k = self.CastKF[:, :-1]
        self.f = self.CastKF[:, -1, np.newaxis]
        self.U = linalg.solve(self.k, self.f).reshape(-1)
        for i in del_dof:
            self.U = np.insert(self.U, i, 0)
        self.U = self.U.reshape(-1,1)

    def ApplyLoad(self):
        self.F[self.loadNodeIndex*2] = 10
        self.CastKF = np.concatenate([self.K, self.F], axis = 1)
        pass

    def GetForce(self):
        self.F = np.dot(self.K, self.U)
        pass

    def CalculateStress(self):
        stress_xx = np.zeros(self.nodeNum)
        stress_yy = np.zeros(self.nodeNum)
        stress_xy = np.zeros(self.nodeNum)
        node_contributions = np.zeros(self.nodeNum)

        D = self.ElasticMatrix(type="Plane Stress")  # 使用平面应力假设下的弹性矩阵

        for i in range(self.elemNum):
            elemNodeSet = self.elementsIndex[i]
            coor = self.nodesCoor[elemNodeSet, :]
            x = coor[:, 0]
            y = coor[:, 1]
            natureInterPoints, weight, pointNum = self.GaussionIntegrate(order=2)

            for integradeIndex in range(pointNum):
                nx = natureInterPoints[0, integradeIndex]
                ny = natureInterPoints[1, integradeIndex]
                B, j_det = self.StrainMatrix(nx, ny, x, y)

                U_elem = np.zeros(8)
                for idx, node_idx in enumerate(elemNodeSet):
                    U_elem[idx * 2] = self.U[node_idx * 2].item()
                    U_elem[idx * 2 + 1] = self.U[node_idx * 2 + 1].item()

                strain_elem = np.dot(B, U_elem)
                stress_elem = np.dot(D, strain_elem)  # 计算应力

                for node_idx_in_elem, global_node_idx in enumerate(elemNodeSet):
                    stress_xx[global_node_idx] += stress_elem[0] * weight * weight * j_det
                    stress_yy[global_node_idx] += stress_elem[1] * weight * weight * j_det
                    stress_xy[global_node_idx] += stress_elem[2] * weight * weight * j_det
                    node_contributions[global_node_idx] += weight * weight * j_det

        for i in range(self.nodeNum):
            if node_contributions[i] != 0:
                stress_xx[i] /= node_contributions[i]
                stress_yy[i] /= node_contributions[i]
                stress_xy[i] /= node_contributions[i]

        stress_vm = np.sqrt(stress_xx ** 2 - stress_xx * stress_yy + stress_yy ** 2 + 3 * stress_xy ** 2)
        return stress_xx, stress_yy, stress_xy,stress_vm
def plot_contour(Coordx, Coordy, Strain, minX, maxX, minY, maxY, figName, ppoints=True):
    global cast_nodes_x
    global cast_nodes_y
    X = np.linspace(minX, maxX, 1000)
    Y = np.linspace(minY, maxY, 1000)

    X1, Y1 = np.meshgrid(X, Y)

    Z = interpolate.griddata((Coordx, Coordy), Strain, (X1, Y1), method='linear')
    Z = np.nan_to_num(Z)
    fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(12, 8))

    minZ = np.min(Z)
    maxZ = np.max(Z)
    levels = np.linspace(minZ, maxZ, 31)
    cset1 = ax.contourf(X1, Y1, Z, levels, cmap=cm.jet)

    mngr = plt.get_current_fig_manager()
    mngr.window.wm_geometry("+350+50")
    ax.set_title(figName, size=20)

    ax.set_xlim(minX, maxX)
    ax.set_ylim(minY, maxY)
    ax.set_xlabel("X(mm)", size=15)
    ax.set_ylabel("Y(mm)", size=15)
    tick_levels = np.linspace(minZ, maxZ, num=20)

    formatter = ticker.FuncFormatter(lambda x, pos: "{:.4g}".format(x))
    cbar = fig.colorbar(cset1, ticks=tick_levels, format=formatter)
    cbar.set_label(' ', size=18)

    if ppoints == True:
        plt.scatter(Coordx, Coordy, marker=".", linewidths=0.5)

    fig.savefig(figName + ".png", bbox_inches='tight', dpi=150, pad_inches=0.1)
    plt.close(fig)
    return ()

if __name__ == "__main__":
    nodesCoor = np.loadtxt("0-nodesCoor.csv", delimiter= ",", dtype=np.float64)
    nodesCoor = nodesCoor[:, [1, 2]]
    elemIndex = np.loadtxt("0-elemindex.csv", delimiter=",", dtype=np.int32).reshape(-1, 5)
    elemIndex = elemIndex[:, 1::] - 1

    loadNodeIndex  = np.array(np.arange(20, 441, 21), dtype=np.int32)
    xCastNodeIndex = np.array(np.arange(0, 421, 21),  dtype=np.int32)
    yCastNodeIndex = np.array(np.arange(0, 21, 1),    dtype=np.int32)

    E = 210000
    u = 0.275
    thickness = 1
    fem_2dplane = Element2D(nodesCoor, elemIndex, xCastNodeIndex, yCastNodeIndex, loadNodeIndex, E = E, u = u, thickness=thickness)
    fem_2dplane.StructStiffness()
    fem_2dplane.ApplyLoad()
    fem_2dplane.ApplyCast()
    fem_2dplane.SolveFEM()
    fem_2dplane.GetForce()
    stress_xx, stress_yy, stress_xy, stress_vm = fem_2dplane.CalculateStress()

    plot_contour(fem_2dplane.nodesCoor[:, 0], fem_2dplane.nodesCoor[:, 1], fem_2dplane.U[0::2].reshape(-1), 0, 1, 0, 1,
                 "My FEM X",ppoints=False)
    plot_contour(fem_2dplane.nodesCoor[:, 0], fem_2dplane.nodesCoor[:, 1], fem_2dplane.U[1::2].reshape(-1), 0, 1, 0, 1,
                 "My FEM Y",ppoints=False)
    plot_contour(fem_2dplane.nodesCoor[:, 0], fem_2dplane.nodesCoor[:, 1], fem_2dplane.F[0::2].reshape(-1), 0, 1, 0, 1,
                 "My FEM FX", ppoints=False)
    plot_contour(fem_2dplane.nodesCoor[:, 0], fem_2dplane.nodesCoor[:, 1], fem_2dplane.F[1::2].reshape(-1), 0, 1, 0, 1,
                 "My FEM FY", ppoints=False)
    plot_contour(fem_2dplane.nodesCoor[:, 0], fem_2dplane.nodesCoor[:, 1], stress_xx, 0, 1, 0, 1,
                 "My FEM Stress XX", ppoints=False)
    plot_contour(fem_2dplane.nodesCoor[:, 0], fem_2dplane.nodesCoor[:, 1], stress_yy, 0, 1, 0, 1,
                 "My FEM Stress YY", ppoints=False)
    plot_contour(fem_2dplane.nodesCoor[:, 0], fem_2dplane.nodesCoor[:, 1], stress_vm, 0, 1, 0, 1,
                 "MISES", ppoints=False)
    fig = plt.figure()
    plt.scatter(fem_2dplane.nodesCoor[:, 0], fem_2dplane.nodesCoor[:, 1])
    plt.scatter(fem_2dplane.nodesCoor[loadNodeIndex, 0], fem_2dplane.nodesCoor[loadNodeIndex, 1], marker="*")
    plt.scatter(fem_2dplane.nodesCoor[xCastNodeIndex, 0], fem_2dplane.nodesCoor[xCastNodeIndex, 1], marker="o")
    plt.show()
    print("Done")

