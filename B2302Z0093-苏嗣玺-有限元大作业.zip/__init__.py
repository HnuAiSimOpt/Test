import scipy.linalg as linalg
from matplotlib import cm
from scipy import interpolate
import matplotlib
matplotlib.use('TkAgg')
import numpy as np
import matplotlib.pyplot as plt
import PlaneFEM
