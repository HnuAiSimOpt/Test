import numpy as np
import matplotlib.pyplot as plt
import matplotlib.tri as tri
import pandas as pd

# 材料属性
E = 210e9  # 弹性模量, Pa
nu = 0.3   # 泊松比
thickness = 0.001  # 板厚, m
load = 100  # 拉伸载荷, N

# 平板尺寸和网格划分
length = 0.5  # 长度, m
width = 0.2   # 宽度, m
num_x = 50    # x方向节点数 (与网格数量相关)
num_y = 20    # y方向节点数
num_nodes = num_x * num_y
dof_per_node = 2
dof_total = num_nodes * dof_per_node

# 生成节点和单元
x_coords = np.linspace(0, length, num_x)
y_coords = np.linspace(0, width, num_y)
x_grid, y_grid = np.meshgrid(x_coords, y_coords)
nodes = np.column_stack((x_grid.flatten(), y_grid.flatten()))

# 三角形网格生成
elements = []
for i in range(num_y - 1):
    for j in range(num_x - 1):
        n1 = i * num_x + j
        n2 = n1 + 1
        n3 = n1 + num_x
        n4 = n3 + 1
        elements.append([n1, n2, n3])
        elements.append([n2, n4, n3])
elements = np.array(elements)

# 绘制网格
def plot_mesh(nodes, elements):
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.set_aspect('equal')
    ax.triplot(nodes[:, 0], nodes[:, 1], elements, color='blue', linewidth=0.5)
    ax.scatter(nodes[:, 0], nodes[:, 1], color='red', s=2)

    # # 添加节点编号
    # for i, (x, y) in enumerate(nodes):
    #     ax.text(x, y, f'{i}', fontsize=12, color='darkred', ha='right', va='bottom', weight='bold')
    #
    # # 添加单元编号
    # for i, element in enumerate(elements):
    #     # 获取单元三个顶点的坐标
    #     x_coords = nodes[element, 0]
    #     y_coords = nodes[element, 1]
    #
    #     # 计算单元的重心坐标，用来放置编号
    #     centroid_x = np.mean(x_coords)
    #     centroid_y = np.mean(y_coords)
    #
    #     # 添加单元编号
    #     ax.text(centroid_x, centroid_y, f'{i}', fontsize=12, color='blue', ha='center', va='center', weight='bold')

    # 添加网格线
    ax.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)

    # 设置标签和标题
    ax.set_xlabel('X Coordinate', fontsize=14, labelpad=10)
    ax.set_ylabel('Y Coordinate', fontsize=14, labelpad=10)
    ax.set_title('Triangular Mesh Visualization', fontsize=16, fontweight='bold')

    # 设置边界
    x_min, x_max = nodes[:, 0].min() - 0.02, nodes[:, 0].max() + 0.02
    y_min, y_max = nodes[:, 1].min() - 0.02, nodes[:, 1].max() + 0.02
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_min, y_max)
    # 显示网格
    plt.tight_layout()

plot_mesh(nodes, elements)

# 计算单元刚度矩阵
def compute_element_stiffness(E, nu, thickness, node_coords):
    # A = 0.5 * abs(np.linalg.det(np.array([[1, node_coords[0, 0], node_coords[0, 1]],
    #                                       [1, node_coords[1, 0], node_coords[1, 1]],
    #                                       [1, node_coords[2, 0], node_coords[2, 1]]])))



    x1, y1 = node_coords[0]
    x2, y2 = node_coords[1]
    x3, y3 = node_coords[2]
    A = 0.5 * abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2))
    D = (E / (1 - nu ** 2)) * np.array([[1, nu, 0],
                                        [nu, 1, 0],
                                        [0, 0, (1 - nu) / 2]])
    B = np.zeros((3, 6))
    for i, j, m in [(0, 1, 2), (1, 2, 0), (2, 0, 1)]:
        xj, yj = node_coords[j]
        xm, ym = node_coords[m]
        B[0, 2 * i] = yj - ym
        B[1, 2 * i + 1] = xm - xj
        B[2, 2 * i] = xm - xj
        B[2, 2 * i + 1] = yj - ym
    B = B / (2 * A)
    K_element = thickness * A * (B.T @ D @ B)
    return K_element

# 计算全局刚度矩阵
K_global = np.zeros((len(nodes) * 2, len(nodes) * 2))

for element in elements:
    node_coords = nodes[element]
    K_element = compute_element_stiffness(E, nu, thickness, node_coords)

    # print("单元刚度矩阵：", K_element)

    for i in range(3):
        for j in range(3):
            K_global[2 * element[i], 2 * element[j]] += K_element[2 * i, 2 * j]
            K_global[2 * element[i] + 1, 2 * element[j] + 1] += K_element[2 * i + 1, 2 * j + 1]
            K_global[2 * element[i], 2 * element[j] + 1] += K_element[2 * i, 2 * j + 1]
            K_global[2 * element[i] + 1, 2 * element[j]] += K_element[2 * i + 1, 2 * j]

# 将刚度矩阵保存为 Excel 文件
df = pd.DataFrame(K_global)
df.to_excel('global_stiffness_matrix2' + '.xlsx', index=False, header=False)

# 假设边界条件
fixed_nodes = []
fixed_node = []
for i in range(num_y):
    fixed_node.append(i*num_x)
for j in fixed_node:
    fixed_nodes.append(2*j)
    fixed_nodes.append(2*j+1)
# 施加力值
force = np.zeros(len(nodes) * 2)
force[-1] = -load
# 施加边界条件
free_nodes = [i for i in range(2*len(nodes)) if i not in fixed_nodes]
K_free = K_global[np.ix_(free_nodes, free_nodes)]
force_free = force[free_nodes]
displacements = np.zeros(len(nodes) * 2)
displacements[free_nodes] = np.linalg.solve(K_free, force_free)
# 计算应力
def compute_stress(E, nu, node_coords, displacements):
    A = 0.5 * abs(np.linalg.det(np.array([[1, node_coords[0, 0], node_coords[0, 1]],
                                          [1, node_coords[1, 0], node_coords[1, 1]],
                                          [1, node_coords[2, 0], node_coords[2, 1]]])))
    D = (E / (1 - nu ** 2)) * np.array([[1, nu, 0],
                                        [nu, 1, 0],
                                        [0, 0, (1 - nu) / 2]])
    B = np.zeros((3, 6))
    for i, j, m in [(0, 1, 2), (1, 2, 0), (2, 0, 1)]:
        xj, yj = node_coords[j]
        xm, ym = node_coords[m]
        B[0, 2 * i] = yj - ym
        B[1, 2 * i + 1] = xm - xj
        B[2, 2 * i] = xm - xj
        B[2, 2 * i + 1] = yj - ym
    B = B / (2 * A)
    stress = D @ B @ displacements
    return stress
# 计算应力
stresses = []
for element in elements:
    node_coords = nodes[element]
    displacements_ele = [0] * (2 * len(element))
    for i in range(len(element)):
        displacements_ele[2 * i] = displacements[2 * element[i]]
        displacements_ele[2 * i + 1] = displacements[2 * element[i] + 1]
    stress = compute_stress(E, nu, node_coords, displacements_ele)
    stresses.append(stress)

# 绘制位移和应力云图
def plot_displacement_cloud(nodes, elements, displacements, direction='x'):
    disp = np.array([displacements[2 * i] for i in range(len(nodes))]) if direction == 'x' else np.array([displacements[2 * i + 1] for i in range(len(nodes))])

    # 创建三角形网格
    fig, ax = plt.subplots()
    ax.set_aspect('equal')
    triang = tri.Triangulation(nodes[:, 0], nodes[:, 1], elements)

    # 绘制云图
    sc = ax.tricontourf(triang, disp, cmap='rainbow')
    fig.colorbar(sc)

    # 显示最大最小值
    min_disp, max_disp = disp.min(), disp.max()
    ax.text(0.95, 0.95, f'Min: {min_disp:.2e}\nMax: {max_disp:.2e}', transform=ax.transAxes,
            fontsize=12, ha='right', va='top', bbox=dict(facecolor='white', edgecolor='black', boxstyle='round'))

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_title(f'Displacement Cloud ({direction} direction)')
    plt.show()

def plot_stress_cloud(nodes, elements, stresses, stress_type='sigma_x', cmap='rainbow'):
    stresses = np.array(stresses)
    if stresses.shape[0] != elements.shape[0]:
        raise ValueError("stresses 长度必须与 elements 的行数一致")

    if stress_type == 'sigma_x':
        stresses_for_plot = stresses[:, 0]
    elif stress_type == 'sigma_y':
        stresses_for_plot = stresses[:, 1]
    elif stress_type == 'tau_xy':
        stresses_for_plot = stresses[:, 2]
    else:
        raise ValueError("无效的 stress_type，选择 'sigma_x', 'sigma_y', 或 'tau_xy'")

    fig, ax = plt.subplots()
    ax.set_aspect('equal')
    triang = tri.Triangulation(nodes[:, 0], nodes[:, 1], elements)

    # 使用 tripcolor 绘制应力云图
    sc = ax.tripcolor(triang, facecolors=stresses_for_plot, cmap=cmap)
    fig.colorbar(sc)

    # 显示最大最小值
    min_stress, max_stress = stresses_for_plot.min(), stresses_for_plot.max()
    ax.text(0.95, 0.95, f'Min: {min_stress:.2e}\nMax: {max_stress:.2e}', transform=ax.transAxes,
            fontsize=12, ha='right', va='top', bbox=dict(facecolor='white', edgecolor='black', boxstyle='round'))

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_title(f'Stress Cloud ({stress_type})')
    plt.show()



# 计算应变

def compute_strain(E, nu, node_coords, displacements):
    """ 计算单元应变 """
    x1, y1 = node_coords[0]
    x2, y2 = node_coords[1]
    x3, y3 = node_coords[2]
    A = 0.5 * abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2))
    B = np.zeros((3, 6))
    for i, j, m in [(0, 1, 2), (1, 2, 0), (2, 0, 1)]:
        xj, yj = node_coords[j]
        xm, ym = node_coords[m]
        B[0, 2 * i] = yj - ym
        B[1, 2 * i + 1] = xm - xj
        B[2, 2 * i] = xm - xj
        B[2, 2 * i + 1] = yj - ym
    B = B / (2 * A)
    strain = B @ displacements
    return strain

# 计算所有单元的应变
strains = []
for element in elements:
    node_coords = nodes[element]
    displacements_ele = np.array([displacements[2 * i:2 * i + 2] for i in element]).flatten()
    strain = compute_strain(E, nu, node_coords, displacements_ele)
    strains.append(strain)

# 应变绘图函数
def plot_strain_cloud(nodes, elements, strains, strain_type='epsilon_x', cmap='rainbow'):
    """ 绘制应变云图 """
    strains = np.array(strains)
    if strains.shape[0] != elements.shape[0]:
        raise ValueError("strains 长度必须与 elements 的行数一致")

    if strain_type == 'epsilon_x':
        strains_for_plot = strains[:, 0]
    elif strain_type == 'epsilon_y':
        strains_for_plot = strains[:, 1]
    elif strain_type == 'gamma_xy':
        strains_for_plot = strains[:, 2]
    else:
        raise ValueError("无效的 strain_type，选择 'epsilon_x', 'epsilon_y', 或 'gamma_xy'")

    fig, ax = plt.subplots()
    ax.set_aspect('equal')
    triang = tri.Triangulation(nodes[:, 0], nodes[:, 1], elements)

    # 使用 tripcolor 绘制应变云图
    sc = ax.tripcolor(triang, facecolors=strains_for_plot, cmap=cmap)
    fig.colorbar(sc)

    # 显示最大最小值
    min_strain, max_strain = strains_for_plot.min(), strains_for_plot.max()
    ax.text(0.95, 0.95, f'Min: {min_strain:.2e}\nMax: {max_strain:.2e}', transform=ax.transAxes,
            fontsize=12, ha='right', va='top', bbox=dict(facecolor='white', edgecolor='black', boxstyle='round'))

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_title(f'Strain Cloud ({strain_type})')
    plt.show()

# 绘制应变云图
plot_strain_cloud(nodes, elements, strains, strain_type='epsilon_x')
plot_strain_cloud(nodes, elements, strains, strain_type='epsilon_y')
plot_strain_cloud(nodes, elements, strains, strain_type='gamma_xy')
# 绘制位移和应力云图
plot_displacement_cloud(nodes, elements, displacements, direction='x')
plot_displacement_cloud(nodes, elements, displacements, direction='y')
plot_stress_cloud(nodes, elements, stresses, stress_type='sigma_x')
plot_stress_cloud(nodes, elements, stresses, stress_type='sigma_y')
plot_stress_cloud(nodes, elements, stresses, stress_type='tau_xy')