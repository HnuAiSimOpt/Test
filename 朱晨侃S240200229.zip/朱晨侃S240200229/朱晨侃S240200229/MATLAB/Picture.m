Nxyz = zeros(nnode,3);
surface=zeros(nx*nz*2+ny*nz*2+nx*ny*2,4);
surfacexz = sym(zeros(1,nx*nz,2));
surfaceyz = sym(zeros(1,ny*nz,2));
surfacexy = sym(zeros(1,nx*ny,2));
for i = 1:nnode
  Nxyz(i,:) = xyz(:,:,i);
end
for i = 0:nnode-1
    nodex(i+1,1) = disp(3*i+1);
    nodey(i+1,1) = disp(3*i+2);
    nodez(i+1,1) = disp(3*i+3);
    nodedis(i+1,1) = sqrt(disp(3*i+1)^2+disp(3*i+2)^2+disp(3*i+3)^2);
end

for i=1:nnode
    strain(i,1) = sqrt(Sstrain(1,i)^2+Sstrain(2,i)^2+Sstrain(3,i)^2+Sstrain(4,i)^2+Sstrain(5,i)^2+Sstrain(6,i)^2);
    stress(i,1) = sqrt(Sstress(1,i)^2+Sstress(2,i)^2+Sstress(3,i)^2+Sstress(4,i)^2+Sstress(5,i)^2+Sstress(6,i)^2);
end
strainx(:,1) = Sstrain(1,:);
strainy(:,1) = Sstrain(2,:);
strainz(:,1) = Sstrain(3,:);
strainxy(:,1) = Sstrain(4,:);
strainyz(:,1) = Sstrain(5,:);
strainxz(:,1) = Sstrain(6,:);
stressx(:,1) = Sstress(1,:);
stressy(:,1) = Sstress(2,:);
stressz(:,1) = Sstress(3,:);
stressxy(:,1) = Sstress(4,:);
stressyz(:,1) = Sstress(5,:);
stressxz(:,1) = Sstress(6,:);

%       
for i=1:nx
    surfacexz(1,i,1)=i;
end
for i=1:nz
    for j=1:nx
        surfacexz(1,j+nx*(i-1),1)=surfacexz(1,j,1)+nx*ny*(i-1);
    end
end

for i=1:ny
    surfaceyz(1,i,1)=nx*i;
end
for i=1:nz
    for j=1:ny
        surfaceyz(1,j+ny*(i-1),1)=surfaceyz(1,j,1)+nx*ny*(i-1);
    end
end

for i=1:nx
    surfacexz(1,i,2)=nx*(ny-1)+i;
end
for i=1:nz
    for j=1:nx
        surfacexz(1,j+nx*(i-1),2)=surfacexz(1,j,2)+nx*ny*(i-1);
    end
end    

for i=1:ny
    surfaceyz(1,i,2)=nx*(i-1)+1;
end
for i=1:nz
    for j=1:ny
        surfaceyz(1,j+ny*(i-1),2)=surfaceyz(1,j,2)+nx*ny*(i-1);
    end
end 

for i=1:nx
    surfacexy(1,i,1)=i;
end
for i=1:ny
    for j=1:nx
        surfacexy(1,j+nx*(i-1),1)=surfacexy(1,j,1)+nx*(i-1);
    end
end 
    
for i=1:nx
    surfacexy(1,i,2)=nx*ny*(nz-1)+i;
end
for i=1:ny
    for j=1:nx
        surfacexy(1,j+nx*(i-1),2)=surfacexy(1,j,2)+nx*(i-1);
    end
end     
    
for j=1:nx*nz
    surface(j,:)=[Enode(1,1,surfacexz(1,j,1)) Enode(1,2,surfacexz(1,j,1)) Enode(1,6,surfacexz(1,j,1)) Enode(1,5,surfacexz(1,j,1))];
end

for j=1:ny*nz
    surface(nx*nz+j,:)=[Enode(1,2,surfaceyz(1,j,1)) Enode(1,3,surfaceyz(1,j,1)) Enode(1,7,surfaceyz(1,j,1)) Enode(1,6,surfaceyz(1,j,1))];
end

for j=1:nx*nz
    surface(nx*nz+ny*nz+j,:)=[Enode(1,3,surfacexz(1,j,2)) Enode(1,4,surfacexz(1,j,2)) Enode(1,8,surfacexz(1,j,2)) Enode(1,7,surfacexz(1,j,2))];
end

for j=1:ny*nz  
    surface(2*nx*nz+ny*nz+j,:)=[Enode(1,1,surfaceyz(1,j,2)) Enode(1,4,surfaceyz(1,j,2)) Enode(1,8,surfaceyz(1,j,2)) Enode(1,5,surfaceyz(1,j,2))];
end

for j=1:nx*ny
    surface(2*nx*nz+2*ny*nz+j,:)=[Enode(1,1,surfacexy(1,j,1)) Enode(1,2,surfacexy(1,j,1)) Enode(1,3,surfacexy(1,j,1)) Enode(1,4,surfacexy(1,j,1))];
end   

for j=1:nx*ny
    surface(3*nx*nz+2*ny*nz+j,:)=[Enode(1,5,surfacexy(1,j,2)) Enode(1,6,surfacexy(1,j,2)) Enode(1,7,surfacexy(1,j,2)) Enode(1,8,surfacexy(1,j,2))];
end

figure('name','    ')
patch('Vertices',Nxyz,'Faces',surface, 'EdgeColor','black','FaceColor','blue','LineWidth',2);
view([45,30]);
axis equal;
axis on;  

figure('name','λ  x')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',nodex,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on;
figure('name','λ  y')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',nodey,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on;
figure('name','λ  z')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',nodez,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on;

figure('name','λ  ')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',nodedis,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on;

figure('name','Ӧ  x')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',strainx,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on;
figure('name','Ӧ  y')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',strainy,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on;
figure('name','Ӧ  z')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',strainz,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on;
figure('name','Ӧ  xy')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',strainxy,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on;
figure('name','Ӧ  yz')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',strainyz,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on;
figure('name','Ӧ  xz')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',strainxz,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on;

figure('name','Ӧ  ')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',strain,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on;

figure('name','Ӧ  x')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',stressx,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on; 
figure('name','Ӧ  y')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',stressy,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on; 
figure('name','Ӧ  z')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',stressz,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on; 
figure('name','Ӧ  xy')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',stressxy,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on;
figure('name','Ӧ  yz')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',stressyz,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on; 
figure('name','Ӧ  xz')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',stressxz,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on; 

figure('name','Ӧ  ')
patch('Vertices',Nxyz,'Faces',surface,'FaceVertexCData',stress,'FaceColor','interp','EdgeAlpha',1);
view([45,30]);
axis equal;
colorbar;
axis on; 