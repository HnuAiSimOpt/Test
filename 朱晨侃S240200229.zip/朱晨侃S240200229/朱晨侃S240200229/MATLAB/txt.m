%-------------------本脚本用于输出计算结果至txt文档--------------------------
fid_out=fopen('六面体单元分析结果.txt','wt');
fprintf(fid_out,'                   六面体单元分析结果\n');
fprintf(fid_out,'节点位移     x           y           z       \n');
fprintf(fid_out,'        %10.6f %10.6f %10.6f\n',disp');
fprintf(fid_out,'节点应力 sigamx     sigamy     sigamz     toux       touy       touz     \n');
fprintf(fid_out,'        %10.6f %10.6f %10.6f %10.6f %10.6f %10.6f\n',Sstress);
fclose(fid_out);