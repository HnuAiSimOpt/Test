function nodestress = Gauss2Phy(Gstress)
% ��������Ϊһ����Ԫ��˹���ֵ㴦��Ӧ��
% -------------�������������ڵ㴦��Ӧ��ֵ��
Ga = [-1/(3^0.5),-1/(3^0.5),-1/(3^0.5);
      1/(3^0.5),-1/(3^0.5),-1/(3^0.5);
      1/(3^0.5),1/(3^0.5),-1/(3^0.5);
      -1/(3^0.5),1/(3^0.5),-1/(3^0.5);
      -1/(3^0.5),-1/(3^0.5),1/(3^0.5);
      1/(3^0.5),-1/(3^0.5),1/(3^0.5);
      1/(3^0.5),1/(3^0.5),1/(3^0.5);
      -1/(3^0.5),1/(3^0.5),1/(3^0.5)];
stab = zeros(8);
for t = 1:8
    stab(t,1) = (1-Ga(t,1))*(1-Ga(t,2))*(1-Ga(t,3))/8;
    stab(t,2) = (1+Ga(t,1))*(1-Ga(t,2))*(1-Ga(t,3))/8;
    stab(t,3) = (1+Ga(t,1))*(1+Ga(t,2))*(1-Ga(t,3))/8;
    stab(t,4) = (1-Ga(t,1))*(1+Ga(t,2))*(1-Ga(t,3))/8;
    stab(t,5) = (1-Ga(t,1))*(1-Ga(t,2))*(1+Ga(t,3))/8;
    stab(t,6) = (1+Ga(t,1))*(1-Ga(t,2))*(1+Ga(t,3))/8;
    stab(t,7) = (1+Ga(t,1))*(1+Ga(t,2))*(1+Ga(t,3))/8;
    stab(t,8) = (1-Ga(t,1))*(1+Ga(t,2))*(1+Ga(t,3))/8;
end
sigam = cell(1,8);
%for i=1:8
%   sigam{i} = stab(i,1)*Gstress(:,1)+stab(i,2)*Gstress(:,2)+stab(i,3)*Gstress(:,3)+stab(i,4)*Gstress(:,4)+stab(i,5)*Gstress(:,5)+stab(i,6)*Gstress(:,6)+stab(i,7)*Gstress(:,7)+stab(i,8)*Gstress(:,8);
%end
tp=stab^(-1);
for i=1:8
   sigam{i}=tp(1,i)*Gstress(:,1)+tp(2,i)*Gstress(:,2)+tp(3,i)*Gstress(:,3)+tp(4,i)*Gstress(:,4)+tp(5,i)*Gstress(:,5)+tp(6,i)*Gstress(:,6)+tp(7,i)*Gstress(:,7)+tp(8,i)*Gstress(:,8);
end
 nodestress = sigam;