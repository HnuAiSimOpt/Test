function [D] = fematiso(E,NU)
%------------------------------------------------------------------------
% ���㵯�Ծ���
% Purpose:
%    determine the constitutive equation for isotropic material
%    three dimensional analysis
%------------------------------------------------------------------------
D = (E/((1+NU)*(1-2*NU)))*[1-NU,NU,NU,0,0,0;
                           NU,1-NU,NU,0,0,0;
                           NU,NU,1-NU,0,0,0;
                           0,0,0,0.5-NU,0,0;
                           0,0,0,0,0.5-NU,0;
                           0,0,0,0,0,0.5-NU];   
